import java.awt.Button;
import java.awt.Color;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

@SuppressWarnings("serial")
public class GUItree extends JFrame{
private Button insert=new Button("����");
private Button search=new Button("��ѯ");
private Button delete=new Button("ɾ��");
private Button show=new Button("��ʾ");
private Button exit=new Button("�˳�");
private TextField id=new TextField();
private TextField data=new TextField();
private TextArea view=new TextArea();


public GUItree(AVLTree tree){
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setBounds(100, 100, 500, 500);
	setBackground(Color.gray);
	setLayout(null);//�����ɱ༭
	
	JLabel jid=new JLabel("������idֵ");
	jid.setBounds(10, 10, 100, 20);
	add(jid);
	
	JLabel jdata=new JLabel("��������ֵ");
	jdata.setBounds(10, 40, 100, 20);
	add(jdata);
	
	id.setBounds(190, 10, 100, 20);
	id.setText("");
	add(id);
	
	data.setBounds(190, 40, 100, 20);
	data.setText("");
	add(data);
	
	view.setBounds(10, 80, 350, 300);
	view.setEditable(false);
	add(view);
	
	
	
	
	insert.setBounds(10, 400, 50, 20);
	search.setBounds(80, 400, 50, 20);
	delete.setBounds(150, 400, 50, 20);
	show.setBounds(220, 400, 50, 20);
	exit.setBounds(210, 440, 50, 20);
	add(insert);
	add(search);
	add(delete);
	add(show);
	add(exit);
	
	
	//�¼�
	insert.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			String qid=id.getText();
			int iid=Integer.parseInt(qid);
			String idata=data.getText();
			if(id.getText()==null||data.getText()==null){
				JOptionPane.showMessageDialog(null, "δ��д������дҪ�����id�Լ�dataֵ");
			}
			else{
			if(tree.get(iid)!=null){
				JOptionPane.showMessageDialog(null, "�ý���Ѵ���");
				id.setText("");
				data.setText("");
			}
			else if(data.getText()!=null){
				tree.insert(iid, new Node(iid,idata));
				JOptionPane.showMessageDialog(null, "�Ѳ���");
				
			}	
			}
			id.setText("");
			data.setText("");
		}
	});
	
	search.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int sid=Integer.parseInt(id.getText());
			if(id.getText()==null){
				JOptionPane.showMessageDialog(null, "Ϊ�գ�����дҪ��ѯ��idֵ");
			}
			if(tree.get(sid)!=null){
				JOptionPane.showMessageDialog(null, "���ҵ���");
					view.setText("��ѯ�Ľ���ǣ�"+tree.get(sid).getId()+tree.get(sid).getData().toString());
				}
			else{
				JOptionPane.showMessageDialog(null, "δ�ҵ�,����������");
				id.setText("");					
			}
			id.setText("");
			data.setText("");
		}		
	});
	
	delete.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int did=Integer.parseInt(id.getText());
			if(id.getText()==null){
				JOptionPane.showMessageDialog(null, "Ϊ�գ�����дҪɾ����idֵ");			
			}
			if(tree.get(did)==null){
				JOptionPane.showMessageDialog(null, "�˽�㲻���ڣ�����������");
			}
			if(tree.get(did)!=null){
				tree.delete(did);
				JOptionPane.showMessageDialog(null, "��ɾ��");
			}
			id.setText("");
			data.setText("");
			view.setText("");
		}
	});
	
	show.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			JTreeGUI jg=new JTreeGUI(tree);
			setVisible(false);
			jg.setVisible(true);
		}
	});
	
	
	
   exit.addActionListener(new ActionListener(){
	   public void actionPerformed(ActionEvent e){
		   setVisible(false);
	   }
   });
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
