import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTree;


@SuppressWarnings("serial")
public class JTreeGUI extends JFrame{	
	public JTreeGUI(AVLTree tree){
		
	
		
		JTree jf=new JTree();
		jf=tree.printTree();
		JFrame avl=new JFrame("AVLTree");
		avl.setSize(500, 500);
		avl.setVisible(true);
		avl.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		avl.add(jf);
		JPanel p =new JPanel(new GridLayout(2,4));
		p.setMaximumSize(new Dimension(400,40));
        p.setMinimumSize(new Dimension(400,40));
        p.setPreferredSize(new Dimension(400,40));
        avl.add(p,BorderLayout.SOUTH);
		
		JButton op=new JButton("����");
		op.setBounds(400, 400, 50, 20);
		p.add(op);
		avl.setVisible(true);
		
		op.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				GUItree gui=new GUItree(tree);
				avl.setVisible(false);
				gui.setVisible(true);
				
			}
		});

		
		
		
		
		
		
	}
	
	
}
