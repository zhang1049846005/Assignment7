
public class Node {
	private int id;
	private Object data;
	private Node parent;
	//private Node[] children = new Node[2];
	private Node lChild;
	private Node rChild;
	//private int lH;
	//private int rH;
	private int balanceFactor;
	
	public Node(){};
	
	public Node(int id,Object data){
		this.id=id;
		this.data=data;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id){
		this.id=id;
	}
	
	public Object getData() {
		return data;
	}
	
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	/*public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	
	public Node getChild(int id){
		return children[id];
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}*/
	
	public Node getlChild(){
		return lChild;
	}
	
	public void setlChild(Node lChild){
		this.lChild=lChild;
	}
	
	public Node getrChild(){
		return rChild;
	}
	
	public void setrChild(Node rChild){
		this.rChild=rChild;
	}

	/*public int getlH() {
		//TODO calculate the left sub tree height
		return lH;
	}
	public int getrH() {
		//TODO calculate the right sub tree height
		return rH;
	}
	*/
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return balanceFactor;
	}
	public void setBalanceFactor(int id){
		this.balanceFactor=id;
	}
	

}

