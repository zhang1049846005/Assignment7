package studio.ziqiang;

import java.io.*;

public class Main {

    public static void main(String[] args) {
        AVLTree avlTree = generateAVLTree("./src/studio/ziqiang/tree_data.dat");

        Frame frame = new Frame(avlTree);
        frame.setVisible(true);

    }

    private static AVLTree generateAVLTree(String filepath) {
        File file = new File(filepath);
        BufferedReader bufferedReader = null;
        AVLTree avlTree = new AVLTree();
        try {
            bufferedReader = new BufferedReader(new FileReader(file));
            String temp;
            int id;
            String data;

            while ((temp = bufferedReader.readLine()) != null) {
                String[] arr = temp.split("\\#");
                data = arr[0];
                id = Integer.parseInt(arr[1]);
                Node node = new Node();
                node.setId(id);
                node.setData(data);
                avlTree.insert(node);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return avlTree;
    }


}
