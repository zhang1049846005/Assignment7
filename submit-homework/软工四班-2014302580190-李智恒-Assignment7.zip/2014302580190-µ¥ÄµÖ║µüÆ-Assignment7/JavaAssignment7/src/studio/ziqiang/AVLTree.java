package studio.ziqiang;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 * Created by Hubert on 15/12/21.
 */
public class AVLTree implements IAVLTree {

    private Node root;
    private int size;


    public int getSize() {
        return size;
    }

    @Override
    public Node get(int id) {

        Node t = root;
        int difference;

        while (t != null) {
            difference = id - t.getId();
            if (difference < 0) {
                t = t.getLeftChild();
            } else if (difference > 0) {
                t = t.getRightChild();
            } else {
                return t;
            }
        }

        return null;
    }

    @Override
    public void insert(Node newNode) {
        Node t = root;

        //空树,当做根节点
        if (t == null) {
            newNode.setBalanceFactor(0);
            root = newNode;
            size = 1;
            return;
        }

        int difference;
        Node parent;
        do {
            parent = t;
            difference = newNode.getId() - t.getId();

            if (difference < 0) {
                t = t.getLeftChild();
            } else if (difference > 0) {
                t = t.getRightChild();
            } else {
                System.out.println("已经存在id为" + newNode.getId() + "的节点");
                return;
            }
        } while (t != null);

        newNode.setParent(parent);

        if (difference < 0) {
            parent.setLeftChild(newNode);
        } else {
            parent.setRightChild(newNode);
        }

        size++;


        //开始回溯
        while (parent != null) {
            difference = newNode.getId() - parent.getId();
            //新插入的节点在当前节点的左子树上
            if (difference < 0) {
                parent.setBalanceFactor(parent.getBalanceFactor()+1);
            } else {
                //新插入的节点在当前节点的右子树上
                parent.setBalanceFactor(parent.getBalanceFactor()-1);
            }

            if (parent.getBalanceFactor() == 0) {
                break;
            }

            if (parent.getBalanceFactor() == 2) {
                leftBalance(parent);
                break;
            }

            if (parent.getBalanceFactor() == -2) {
                rightBalance(parent);
                break;
            }

            parent = parent.getParent();
        }

    }


    @Override
    public void delete(int id) {

        Node node = get(id);

        if (node == null) {
            return;
        }

        size--;


        if (node.hasTwoChildren()) {
            Node directSuccessor = directSuccessor(node);
            node.setData(directSuccessor.getData());
            node.setId(directSuccessor.getId());
            node = directSuccessor;
        }

        Node onlyChild = null;
        if (node.getLeftChild() != null) {
            onlyChild = node.getLeftChild();
        }
        if (node.getRightChild() != null) {
            onlyChild = node.getRightChild();
        }

        if (onlyChild != null) {
            //有一个孩子
            onlyChild.setParent(node.getParent());

            if (node.getParent() == null) {
                root = onlyChild;
            } else if (node == node.getParent().getLeftChild()) {
                node.getParent().setLeftChild(onlyChild);
            } else if (node == node.getParent().getRightChild()) {
                node.getParent().setRightChild(onlyChild);
            }

            node.setLeftChild(null);
            node.setRightChild(null);
            node.setParent(null);

            rebalanceAfterDeleting(onlyChild);

        } else if (node.getParent() == null) {
            //树中只有唯一的节点
            root = null;
        } else {
            //无孩子
            rebalanceAfterDeleting(node);

            if (node.getParent() != null) {
                if (node == node.getParent().getLeftChild()) {
                    node.getParent().setLeftChild(null);
                } else if (node == node.getParent().getRightChild()) {
                    node.getParent().setRightChild(null);
                }
                node.setParent(null);
            }
        }

    }

    private void rebalanceAfterDeleting(Node node) {

        boolean shorter = true;
        Node parent = node.getParent();

        int difference;
        while (parent != null && shorter) {
            difference = node.getId() - parent.getId();
            if (difference >= 0) {
                parent.setBalanceFactor(parent.getBalanceFactor() + 1);
            } else {
                parent.setBalanceFactor(parent.getBalanceFactor() - 1);
            }

            if (parent.getBalanceFactor() == 1 || parent.getBalanceFactor() == -1) {
                break;
            }

            if (parent.getBalanceFactor() == 2) {
                shorter = leftBalance(parent);
            } else if (parent.getBalanceFactor() == -2) {
                shorter = rightBalance(parent);
            }

            parent = parent.getParent();
        }

    }

    private Node directSuccessor(Node node) {

        if (node == null) {
            return null;
        }

        if (node.getRightChild() == null) {
            Node parent = node.getParent();
            Node child = node;
            while (parent != null && child == parent.getRightChild()) {
                child = parent;
                parent = parent.getParent();
            }
            return parent;
        } else {
            Node parent = node.getRightChild();
            while (parent.getLeftChild() != null) {
                parent = parent.getLeftChild();
            }
            return parent;
        }

    }

    @Override
    public JTree printTree() {


        if (root == null) {
            return null;
        }

        DefaultMutableTreeNode root = createNode(this.root);
        JTree jTree = new JTree(root);
        return jTree;
    }

    private DefaultMutableTreeNode createNode(Node node) {

        DefaultMutableTreeNode treeNode = new DefaultMutableTreeNode(node);
        if (node.getLeftChild() != null) {
            treeNode.add(createNode(node.getLeftChild()));
        }
        if (node.getRightChild() != null) {
            treeNode.add(createNode(node.getRightChild()));
        }
        return treeNode;
    }

    private void rightRotation(Node p) {

        if (p == null) {
            return;
        }

        Node r = p.getRightChild();
        p.setRightChild(r.getLeftChild());
        if (r.getLeftChild()!=null) {
            r.getLeftChild().setParent(p);
        }
        r.setParent(p.getParent());

        //修改p的parent的子节点
        if (p.getParent() == null) {
            root = r;
        } else if (p.getParent().getLeftChild() == p) {
            p.getParent().setLeftChild(r);
        } else {
            p.getParent().setRightChild(r);
        }

        r.setLeftChild(p);
        p.setParent(r);
    }

    private void leftRotation(Node p) {

        if (p == null) {
            return;
        }

        Node l = p.getLeftChild();
        p.setLeftChild(l.getRightChild());
        if (l.getRightChild()!=null) {
            l.getRightChild().setParent(p);
        }
        l.setParent(p.getParent());

        //修改p的parent的子节点
        if (p.getParent() == null) {
            root = l;
        } else if (p.getParent().getRightChild() == p) {
            p.getParent().setRightChild(l);
        } else {
            p.getParent().setLeftChild(l);
        }

        l.setRightChild(p);
        p.setParent(l);
    }

    private boolean leftBalance(Node node) {
        Node l = node.getLeftChild();

        switch (l.getBalanceFactor()) {
            case 1: {
                node.setBalanceFactor(0);
                l.setBalanceFactor(0);
                leftRotation(node);
                break;
            }
            case -1: {
                Node lr = l.getRightChild();
                switch (lr.getBalanceFactor()) {
                    case 1: {
                        node.setBalanceFactor(-1);
                        l.setBalanceFactor(0);
                        break;
                    }
                    case 0: {
                        node.setBalanceFactor(0);
                        l.setBalanceFactor(0);
                        break;
                    }
                    case -1: {
                        node.setBalanceFactor(0);
                        l.setBalanceFactor(1);
                    }
                }
                lr.setBalanceFactor(0);
                rightRotation(l);
                leftRotation(node);
                break;
            }
            case 0: {
                l.setBalanceFactor(-1);
                node.setBalanceFactor(1);
                leftRotation(node);
                return false;
            }
        }
        return true;
    }

    private boolean rightBalance(Node node) {
        Node r = node.getRightChild();

        switch (r.getBalanceFactor()) {
            case 1: {
                Node rl = node.getLeftChild();
                switch (rl.getBalanceFactor()) {
                    case 1: {
                        node.setBalanceFactor(0);
                        r.setBalanceFactor(-1);
                        break;
                    }
                    case 0: {
                        node.setBalanceFactor(0);
                        r.setBalanceFactor(0);
                        break;
                    }
                    case -1: {
                        node.setBalanceFactor(1);
                        r.setBalanceFactor(0);
                        break;
                    }
                }
                rl.setBalanceFactor(0);
                leftRotation(r);
                rightRotation(node);
                break;
            }
            case -1: {
                node.setBalanceFactor(0);
                r.setBalanceFactor(0);
                rightRotation(node);
                break;
            }
            case 0: {
                r.setBalanceFactor(1);
                node.setBalanceFactor(-1);
                rightRotation(node);
                return false;
            }
        }
        return true;
    }

    public void inOrderTraversal() {

        if (root == null) {
            System.out.println("树为空");
            return;
        }

        inOrder(root);

    }

    private void inOrder(Node node) {
        if (node == null) {
            return;
        }

        inOrder(node.getLeftChild());
        System.out.println("id: " + node.getId() + "\tdata: " + node.getData());
        inOrder(node.getRightChild());
    }

    public Node getRoot() {
        return root;
    }
}
