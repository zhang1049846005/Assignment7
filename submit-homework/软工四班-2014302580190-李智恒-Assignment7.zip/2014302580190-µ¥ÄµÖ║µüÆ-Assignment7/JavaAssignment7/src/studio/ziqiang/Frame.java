package studio.ziqiang;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Hubert on 15/12/23.
 */
public class Frame extends JFrame {

    JTree tree;
    AVLTree avlTree;

    public Frame(final AVLTree avlTree) {
        super("AVLTree");
        this.avlTree = avlTree;
        setSize(800, 800);
        setLayout(null);
        setResizable(false);
        this.tree = avlTree.printTree();
        addTree();

        final JTextField queryTextfield = new JTextField();
        queryTextfield.setBounds(170, 500, 100, 50);
        add(queryTextfield);

        JLabel queryLabel = new JLabel("请输入想要查询的节点id: ");
        queryLabel.setBounds(10, 500, 150, 50);
        add(queryLabel);

        final JLabel resultLabel = new JLabel();
        resultLabel.setBounds(470, 500, 200, 50);
        add(resultLabel);

        JButton queryButton = new JButton("确定查询");
        queryButton.setBounds(320, 500, 100, 50);
        queryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(queryTextfield.getText());
                    Node result = avlTree.get(id);
                    if (result == null) {
                        resultLabel.setText("无结果");
                    } else {
                        resultLabel.setText(result.toString());
                    }

                } catch (NumberFormatException err) {
                    JOptionPane.showMessageDialog(null, "请输入数字", "错误", JOptionPane.ERROR_MESSAGE);
                    err.printStackTrace();
                }
            }
        });
        add(queryButton);



        final JTextField insertTextField = new JTextField();
        insertTextField.setBounds(200, 650, 100, 50);
        add(insertTextField);

        JLabel insertLabel = new JLabel("请输入要插入的节点id和data,格式id+data");
        insertLabel.setBounds(200, 600, 250, 50);
        add(insertLabel);

        JButton insertButton = new JButton("确定插入");
        insertButton.setBounds(200, 720, 100, 50);
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    String[] arr = insertTextField.getText().split("\\+");
                    if (arr.length != 2) {
                        JOptionPane.showMessageDialog(null, "格式错误,请输入正确格式", "错误", JOptionPane.ERROR_MESSAGE);
                    } else {
                        int id = Integer.parseInt(arr[0]);
                        tree.setVisible(false);
                        remove(tree);
                        String data = arr[1];
                        Node node = new Node();
                        node.setId(id);
                        node.setData(data);
                        Frame.this.avlTree.insert(node);
                        tree = Frame.this.avlTree.printTree();
                        addTree();
                    }

                } catch (NumberFormatException err) {
                    JOptionPane.showMessageDialog(null, "请输入数字", "错误", JOptionPane.ERROR_MESSAGE);
                    insertTextField.setText("");
                    err.printStackTrace();
                }
            }
        });
        add(insertButton);




        final JTextField deleteTextField = new JTextField();
        deleteTextField.setBounds(500, 650, 100, 50);
        add(deleteTextField);

        JLabel deleteLabel = new JLabel("请输入要删除的节点id: ");
        deleteLabel.setBounds(500, 600, 150, 50);
        add(deleteLabel);

        JButton deleteButton = new JButton("确定删除");
        deleteButton.setBounds(500, 720, 100, 50);
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Frame.this.avlTree.delete(Integer.parseInt(deleteTextField.getText()));
                    tree.setVisible(false);
                    remove(tree);
                    tree = Frame.this.avlTree.printTree();
                    addTree();
                } catch (NumberFormatException error) {
                    JOptionPane.showMessageDialog(null, "请输入数字", "错误", JOptionPane.ERROR_MESSAGE);
                    deleteTextField.setText("");
                    error.printStackTrace();
                }

            }
        });
        add(deleteButton);




    }

    private void addTree() {
        if (tree != null) {
            tree.setBounds(100, 50, 600, 400);
            tree.setVisible(true);
            add(tree);
        }
    }
}
