package studio.ziqiang;

public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	private Node[] getChildren() {
		return children;
	}
	public Node getLeftChild() {
		return getChildren()[0];
	}

	public Node getRightChild() {
		return getChildren()[1];
	}

	public void setLeftChild(Node leftChild) {
		setChild(leftChild, 0);
	}

	public void setRightChild(Node rightChild) {
		setChild(rightChild, 1);
	}

	private void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		return balanceFactor;
	}


	public void setBalanceFactor(int balanceFactor) {
		this.balanceFactor = balanceFactor;
	}

	public boolean hasTwoChildren() {
		if (this.getLeftChild() != null && this.getRightChild() != null) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "id: " + getId() + " data: " + getData();
	}
}
