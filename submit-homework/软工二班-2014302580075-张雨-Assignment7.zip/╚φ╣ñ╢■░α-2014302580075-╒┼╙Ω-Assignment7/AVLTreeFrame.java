package avltree;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTree;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextArea;

public class AVLTreeFrame extends JFrame {

	private JPanel contentPane;
	private JTextField txtInsertnodeid;
	private JTextField txtInsertnodedata;
	private JTextField txtDeletenodeid;
	private JButton btnInsertnode = new JButton("InsertNode");
	private JButton btnDeletenode = new JButton("DeleteNode");
	private JTree tree;
	private AVLTree avlTree=new AVLTree();
	private JScrollPane scrollPane;
	private DefaultTreeModel dTreeModel;
	private JTextField txtGetnodeid;
	private JTextArea textArea;
	
	public JTree getTree() {

		return avlTree.printTree();
		
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		AVLTreeFrame avlTreeFrame=new AVLTreeFrame();
		avlTreeFrame.setVisible(true);
	}
	/**
	 * Create the frame.
	 */
	public AVLTreeFrame() {
		setTitle("AVLTreeGUI");
		//��ʼ���ڵ�
		Node a=new Node(1, "ant");
		Node b=new Node(2, "apple");
		Node c=new Node(3, "art");
		Node d=new Node(4, "baby");
		Node e=new Node(5, "banan");
		Node f=new Node(6, "car");
		Node g=new Node(7, "door");
		Node h=new Node(8, "dress");
		Node i=new Node(9, "frog");
		Node j=new Node(10, "love");
		Node k=new Node(11, "mint");
		Node l=new Node(12, "rice");
		Node m=new Node(13, "show");
		Node n=new Node(14, "table");
		Node o=new Node(15, "tree");
		Node p=new Node(16, "trouble");
		Node q=new Node(17, "window");
		
		
		avlTree.insert(a);avlTree.printFromRoot();
		avlTree.insert(b);avlTree.printFromRoot();
		avlTree.insert(c);avlTree.printFromRoot();
		avlTree.insert(d);avlTree.printFromRoot();
		avlTree.insert(e);avlTree.printFromRoot();
		avlTree.insert(f);avlTree.printFromRoot();
		avlTree.insert(g);avlTree.printFromRoot();
		avlTree.insert(h);avlTree.printFromRoot();
		avlTree.insert(i);avlTree.printFromRoot();
		avlTree.insert(j);avlTree.printFromRoot();
		avlTree.insert(k);avlTree.printFromRoot();
		avlTree.insert(l);avlTree.printFromRoot();
		avlTree.insert(m);avlTree.printFromRoot();
		avlTree.insert(n);avlTree.printFromRoot();
		avlTree.insert(o);avlTree.printFromRoot();
		avlTree.insert(p);avlTree.printFromRoot();
		avlTree.insert(q);avlTree.printFromRoot();
		avlTree.printFromRoot();
		System.out.println("*************************************************************");
		Node root=avlTree.getRoot();
		if (root!=null) {
			System.out.println("root.id="+root.getId());
		}
		
		avlTree.printFromRoot();
		//��ʼ�����
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 607, 396);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		btnInsertnode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				insertNodeEvent(arg0);
			}
		});
		
		
		btnInsertnode.setBounds(0, 10, 118, 23);
		contentPane.add(btnInsertnode);
		
		txtInsertnodeid = new JTextField();
		txtInsertnodeid.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				clearDefaultInsertId(arg0);
			}
		});
		txtInsertnodeid.setText("InsertNodeId");
		txtInsertnodeid.setBounds(128, 11, 107, 21);
		contentPane.add(txtInsertnodeid);
		txtInsertnodeid.setColumns(10);
		
		txtInsertnodedata = new JTextField();
		txtInsertnodedata.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				clearDefaultInsertData(e);
			}
		});
		txtInsertnodedata.setText("InsertNodeData");
		txtInsertnodedata.setBounds(264, 11, 201, 21);
		contentPane.add(txtInsertnodedata);
		txtInsertnodedata.setColumns(10);
		btnDeletenode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteNodeEvent(e);
			}
		});
		
		
		btnDeletenode.setBounds(0, 43, 118, 23);
		contentPane.add(btnDeletenode);
		
		txtDeletenodeid = new JTextField();
		txtDeletenodeid.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				clearDefaultDeleteId(e);
			}
		});
		txtDeletenodeid.setText("DeleteNodeId");
		txtDeletenodeid.setBounds(128, 44, 107, 21);
		contentPane.add(txtDeletenodeid);
		txtDeletenodeid.setColumns(10);
		
		dTreeModel=new DefaultTreeModel(avlTree.getTreeRoot());
		tree=new JTree(dTreeModel);
		tree.setBounds(0, 86, 482, 261);
		
		scrollPane = new JScrollPane(tree);
		scrollPane.setBounds(0, 76, 433, 281);
		contentPane.add(scrollPane);
		
		textArea = new JTextArea();
		textArea.setBounds(443, 76, 138, 281);
		contentPane.add(textArea);
		
		JButton btnGetnode = new JButton("GetNode");
		btnGetnode.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				getNodeEvent(e);
			}
		});
		btnGetnode.setBounds(340, 43, 93, 23);
		contentPane.add(btnGetnode);
		
		txtGetnodeid = new JTextField();
		txtGetnodeid.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				clearDefaultGetNodeId(arg0);
			}
		});
		txtGetnodeid.setText("GetNodeId");
		txtGetnodeid.setBounds(443, 44, 138, 21);
		contentPane.add(txtGetnodeid);
		txtGetnodeid.setColumns(10);
	}
	protected void getNodeEvent(MouseEvent e) {
		if (txtGetnodeid.getText()==null||"".equals(txtGetnodeid.getText().trim())) {
			JOptionPane.showMessageDialog(null, "��������ȷ��ֵ��");
		}else {
			textArea.setText("");
			int id=Integer.parseInt(txtGetnodeid.getText());
			Node node=avlTree.get(id);
			if (node!=null) {
				textArea.setText("Id:"+node.getId()+"\nData:"+node.getData());
			}else {
				textArea.setText("null");
			}
			
		}
		
	}
	protected void clearDefaultGetNodeId(MouseEvent arg0) {
		txtGetnodeid.setText("");
		
	}
	protected void clearDefaultDeleteId(MouseEvent e) {
		txtDeletenodeid.setText("");
		
	}
	protected void clearDefaultInsertData(MouseEvent e) {
		txtInsertnodedata.setText("");
		
	}
	protected void clearDefaultInsertId(MouseEvent arg0) {
		txtInsertnodeid.setText("");
		
	}
	protected void deleteNodeEvent(ActionEvent e) {
		if (txtDeletenodeid.getText()==null||"".equals(txtDeletenodeid.getText().trim())) {
			JOptionPane.showMessageDialog(null, "��������ȷ��ֵ��");
		}else {
			int id=Integer.parseInt(txtDeletenodeid.getText());
			avlTree.delete(id);
			avlTree.printFromRoot();
			
			dTreeModel.setRoot(avlTree.getTreeRoot());
			dTreeModel.reload();
			tree.setModel(dTreeModel);
			tree.updateUI();
		}
		
	}
	protected void insertNodeEvent(ActionEvent arg0) {
		if (txtInsertnodeid.getText()==null||"".equals(txtInsertnodeid.getText().trim())) {
			JOptionPane.showMessageDialog(null, "IDΪ�գ���������ȷ��ֵ��");
		}else if (txtInsertnodedata.getText()==null||"".equals(txtInsertnodedata.getText().trim())) {
			JOptionPane.showMessageDialog(null, "DataΪ�գ���������ȷ��ֵ��");
		}else {
			int id=Integer.parseInt(txtInsertnodeid.getText());
			String data=txtInsertnodedata.getText();
			Node insertNode=new Node(id, data);
			avlTree.insert(insertNode);
			avlTree.printFromRoot();
			
			dTreeModel.setRoot(avlTree.getTreeRoot());
			dTreeModel.reload();
			tree.setModel(dTreeModel);
			tree.updateUI();
		}
		
	}
}
