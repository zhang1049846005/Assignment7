package avltree;

public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	private int height;
	
	public Node(int id,Object data) {
		
		this.data=data;
		this.id=id;
		children[0]=null;
		children[1]=null;
		parent=null;
		lSubTreeHeight=0;
		rSubTreeHeight=0;
		height=0;
		balanceFactor=0;
	}
	
	
	public int getHeight() {
		height=Math.max(this.getlSubTreeHeight(), this.getrSubTreeHeight())+1;
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		if (this.children[0]==null) {
			lSubTreeHeight=0;
		}else {
			lSubTreeHeight=Math.max(this.children[0].lSubTreeHeight, this.children[0].rSubTreeHeight)+1;
		}
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {

		if (this.children[1]==null) {
			rSubTreeHeight=0;
		}else {
			rSubTreeHeight=Math.max(this.children[1].lSubTreeHeight, this.children[1].rSubTreeHeight)+1;
		}
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();
		return balanceFactor;
	}
	

}
