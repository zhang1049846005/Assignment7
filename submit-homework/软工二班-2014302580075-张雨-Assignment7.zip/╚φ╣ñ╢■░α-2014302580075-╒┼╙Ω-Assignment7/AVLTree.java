package avltree;

import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;


public class AVLTree implements IAVLTree{

	
	private Node root;
	
	
	public AVLTree() {
		root=null;
	}
	
	public Node getRoot() {
		return root;
	}
	
	@Override
	public Node get(int id) {
		Node tmp=search(root, id);
		return tmp;
	}
	public Node search(Node node,int id) {
		Node tmp=null;
		if (node!=null) {
			
			if (id==node.getId()) {
				tmp=node;
			}
			if (id<node.getId()) {
				tmp=search(node.getChildren()[0], id);
			}
			if (id>node.getId()) {
				tmp=search(node.getChildren()[1], id);
			}
			
		}
		return tmp;
	}
	
	public void insert(Node newNode) {
		System.out.println("��ʼ���룺"+newNode.getId());
		if (root==null) {
			root=newNode;
			root.setParent(null);
		}else {
			root=insert(root, newNode);//
			root.setParent(null);
		}
		System.out.println("root:"+root.getId());
	}
	
	public Node insert(Node toNode,Node newNode) {
		//�������Ҳ����ж�
		if (newNode.getId()<=toNode.getId()) {
			System.out.println("�������");
			if (toNode.getChildren()[0]==null) {
				toNode.setChild(newNode, 0);
				newNode.setParent(toNode);
			}else {
				Node n=insert(toNode.getChildren()[0], newNode);
				toNode.setChild(n, 0);
				if (n!=null) {
					n.setParent(toNode);
				}
				
			}
			//��������ת�ж�
			System.out.println("toNode.id="+toNode.getId()+"\ttoNode.blanceFactor="+toNode.getBalanceFactor());
			if (toNode.getBalanceFactor()==2) {
				
				if (toNode.getChildren()[0].getBalanceFactor()==1) {
					System.out.println("toNode.id="+toNode.getId()+"\ttoNode.blanceFactor="+toNode.getBalanceFactor());
					toNode=lSingleRotation(toNode);
				}else if(toNode.getChildren()[0].getBalanceFactor()==-1){
					System.out.println("toNode.id="+toNode.getId()+"\ttoNode.blanceFactor="+toNode.getBalanceFactor());
					toNode=lDoubleRotation(toNode);
				}
				
			}
			
		}
		//���Ҳ���
		if (newNode.getId()>toNode.getId()) {
			System.out.println("toNode.id="+toNode.getId()+"\ttoNode.blanceFactor="+toNode.getBalanceFactor());
			System.out.println("���Ҳ���");
			if (toNode.getChildren()[1]==null) {
				toNode.setChild(newNode, 1);
				newNode.setParent(toNode);
			}else {
				Node n=insert(toNode.getChildren()[1], newNode);
				toNode.setChild(n, 1);
				if (n!=null) {
					n.setParent(toNode);
				}
				
			}
			//��������ת�ж�
			
			if (toNode.getBalanceFactor()==-2) {
				
				if (toNode.getChildren()[1].getBalanceFactor()==-1) {
					System.out.println("toNode.id="+toNode.getId()+"\ttoNode.blanceFactor="+toNode.getBalanceFactor());
					toNode=rSingleRotation(toNode);
				}
				if (toNode.getChildren()[1].getBalanceFactor()==1) {
					System.out.println("toNode.id="+toNode.getId()+"\ttoNode.blanceFactor="+toNode.getBalanceFactor());
					toNode=rDoubleRotation(toNode);
				}
			}
		}

		System.out.println("������ϡ�������������������������");
		System.out.println("toNode.id="+toNode.getId()+"\ttoNode.blanceFactor="+toNode.getBalanceFactor());
		return toNode;
	}
	//�жϽڵ��Ƿ���Ҫ������ת
	public Node checkBlanceFactor(Node checkNode) {
		if (checkNode!=null) {
			//����ת
			if (checkNode.getBalanceFactor()==2) {
				
				if (checkNode.getChildren()[0].getBalanceFactor()==1) {
					checkNode=lSingleRotation(checkNode);
				}
				if (checkNode.getChildren()[0].getBalanceFactor()==-1) {
					checkNode=lDoubleRotation(checkNode);
				}
				
			}
			//����ת
			if (checkNode.getBalanceFactor()==-2) {
				if (checkNode.getChildren()[1].getBalanceFactor()==-1) {
					checkNode=rSingleRotation(checkNode);
				}
				if (checkNode.getChildren()[1].getBalanceFactor()==1) {
					checkNode=rDoubleRotation(checkNode);
				}
			}
		
		}
		return checkNode;
	}
	//���ڵ�ɾ��
	public Node delete(Node node,int id) {
		System.out.println("node.id="+node.getId()+"\t"+id);
		if (node!=null) {
			//�����Ѱ��
			if (id<node.getId()) {
				if (node.getChildren()[0]==null) {
					JOptionPane.showMessageDialog(null, "ɾ���Ľ�㲻���ڣ���������ȷ��ֵ��");
				}
			else if (id==node.getChildren()[0].getId()) {
				
				node.getChildren()[0]=delete(node.getChildren()[0]);
				node.getChildren()[0]=checkBlanceFactor(node.getChildren()[0]);
				if (node.getChildren()[0]!=null) {
					node.getChildren()[0].setParent(node);
				}
			}else {
				node.getChildren()[0]=delete(node.getChildren()[0], id);
				node.getChildren()[0]=checkBlanceFactor(node.getChildren()[0]);
				if (node.getChildren()[0]!=null) {
					node.getChildren()[0].setParent(node);
				}
			}
				
			}
			//���ұ�Ѱ��
			if (id>node.getId()) {
				if (node.getChildren()[1]==null) {
					JOptionPane.showMessageDialog(null, "ɾ���Ľ�㲻���ڣ���������ȷ��ֵ��");
				}
				else if (id==node.getChildren()[1].getId()) {
					node.getChildren()[1]=delete(node.getChildren()[1]);
					node.getChildren()[1]=checkBlanceFactor(node.getChildren()[1]);
					if (node.getChildren()[1]!=null) {
						node.getChildren()[1].setParent(node);
					}
					
				}else {
					node.getChildren()[1]=delete(node.getChildren()[1], id);
					node.getChildren()[1]=checkBlanceFactor(node.getChildren()[1]);
					if (node.getChildren()[1]!=null) {
						node.getChildren()[1].setParent(node);
					}
				}
			}

		}
		return node;
	}
	
	public Node delete(Node deleNode) {
		Node temp=deleNode.getParent();
		if (temp!=null) {
			System.out.println("deleNode.parent="+temp.getId());
			System.out.println("deleNode.id="+deleNode.getId());
		}
		//���´�������ҵ���Ӧ�ڵ�֮������
		//ɾ������Ҷ�ӽڵ�
		if (deleNode.getChildren()[0]==null&&deleNode.getChildren()[1]==null) {
			deleNode=null;
		}
		
		//ɾ������֦�ɽڵ�,��Ϊ���¼������
		
		//ɾ���Ľڵ���������
		else if (deleNode.getChildren()[0]!=null&&deleNode.getChildren()[1]==null) {
			deleNode=deleNode.getChildren()[0];
		}
		//ɾ���Ľڵ���������
		else if (deleNode.getChildren()[0]==null&&deleNode.getChildren()[1]!=null) {
			deleNode=deleNode.getChildren()[1];
		}
		//ɾ���Ľڵ�����������
		else if (deleNode.getChildren()[0]!=null&&deleNode.getChildren()[1]!=null) {
			Node LeftSubTreeRightNode=getLeftSubTreeRightNode(deleNode);//LSTRN
			deleNode.setData(LeftSubTreeRightNode.getData());
			deleNode.setId(LeftSubTreeRightNode.getId());
			deleNode.getChildren()[0]=operateLeftSubTreeRightNode(deleNode.getChildren()[0]);
		}
		return deleNode;
	}
	
	@Override
	public void delete(int id) {
		//����Ĵ����ǶԽڵ���в���
		System.out.println("deleteNode.id="+id);
		if (root!=null) {
			if (root.getId()==id) {
				root=delete(root);
				root.setParent(null);
			}else {
				root=delete(root, id);
				
			}
			
		}else {
			System.out.println("root=null;");
		}
		
	}
	//�Ի��node�����������ұߵĽڵ���в����������õĽڵ�����Ӹ�ֵ������ڵ㣬Ȼ����з��ز���
	
	private Node operateLeftSubTreeRightNode(Node subTreeNode) {
		if (subTreeNode.getChildren()[1]==null) {
			subTreeNode=subTreeNode.getChildren()[0];
		}else {
			subTreeNode.getChildren()[1]=operateLeftSubTreeRightNode(subTreeNode.getChildren()[1]);
		}
		
		return subTreeNode;
	}
	
	//��node�������������ұߵĽڵ�
	public Node getLeftSubTreeRightNode(Node node) {
		Node tmp=null;
		if (node.getChildren()[0].getChildren()[1]==null) {
			tmp=node.getChildren()[0];
		}else {
			tmp=getRightNode(node.getChildren()[0].getChildren()[1]);
			
		}
		return tmp;
	}
	//������������ұߵĽڵ�
	public Node getRightNode(Node node) {
		Node tmp=null;
		if (node.getChildren()[1]==null) {
			tmp=node;
		}else {
			tmp=getRightNode(node.getChildren()[1]);
		}
		return tmp;
	}
	public void printFromRoot() {
		System.out.println("print:***********************************begain");
		print(root);
		System.out.println("print:**********************************end;");
	}
	public void print(Node node) {
		if (node!=null) {
			print(node.getChildren()[0]);
			System.out.println(node.getId()+":"+node.getData()+"\tblanceFactor="+node.getBalanceFactor()+"\theight="+node.getHeight());
			
			if (node.getParent()!=null) {
				System.out.println("\tParent:"+node.getParent().getId());
			}else {
				System.out.println("\tParent:null");
			}
			if (node.getChildren()[0]!=null) {
				System.out.println("\tLchildren:"+node.getChildren()[0].getId());
			}else {
				System.out.println("\tLchildren:null");
			}
			if (node.getChildren()[1]!=null) {
				System.out.println("\tRchildren:"+node.getChildren()[1].getId());
			} else {
				System.out.println("\tRchildren:null");
			}
			print(node.getChildren()[1]);
		}
	}
	
	@Override
	public JTree printTree() {
		DefaultMutableTreeNode treeRoot=new DefaultMutableTreeNode(new String("Root:"+Integer.toString(root.getId())+":"+root.getData()));
		getTreeNode(treeRoot, root);
		JTree jTree=new JTree(treeRoot);
		
		return jTree;
	}
	public DefaultMutableTreeNode getTreeRoot() {
		DefaultMutableTreeNode treeRoot=new DefaultMutableTreeNode(new String("Root:"+Integer.toString(root.getId())+":"+root.getData()));
		DefaultMutableTreeNode node=treeRoot;
		getTreeNode(treeRoot, root);
		return treeRoot;
	}
	private DefaultMutableTreeNode getTreeNode(DefaultMutableTreeNode treeNode,Node node) {
		if (node!=null) {
			
			if (node.getChildren()[0]!=null) {
				DefaultMutableTreeNode lTreeNode=new DefaultMutableTreeNode("Lchildren:"+new String(Integer.toString(node.getChildren()[0].getId())+":"+node.getChildren()[0].getData()));
				treeNode.add(lTreeNode);
				getTreeNode(lTreeNode, node.getChildren()[0]);
			}
			if (node.getChildren()[1]!=null) {
				DefaultMutableTreeNode rTreeNode=new DefaultMutableTreeNode("Rchildren:"+new String(Integer.toString(node.getChildren()[1].getId())+":"+node.getChildren()[1].getData()));
				treeNode.add(rTreeNode);
				getTreeNode(rTreeNode, node.getChildren()[1]);
			}
			
			
		}
		return treeNode;
	}
	
	//��ߵ���ת
	public Node lSingleRotation(Node adjNode) {
		
		System.out.println("��ߵ���ת");
		System.out.println("adjNode.id="+adjNode.getId());
		Node u=adjNode;
		Node r=adjNode.getChildren()[0];

		u.setChild(r.getChildren()[1], 0);
		if (r.getChildren()[1]!=null) {
			r.getChildren()[1].setParent(u);
		}
		
		r.setChild(u, 1);
		if (u!=null) {
			u.setParent(r);
		}
		
		adjNode=r;
		return adjNode;
	}
	//���˫��ת
	public Node lDoubleRotation(Node adjNode) {
		
		System.out.println("���˫��ת");
		System.out.println("adjNode.id="+adjNode.getId());
		Node u=adjNode;
		Node r=adjNode.getChildren()[0];
		Node s=r.getChildren()[1];
		
		r.setChild(s.getChildren()[0], 1);
		if (s.getChildren()[0]!=null) {
			s.getChildren()[0].setParent(r);
		}

		u.setChild(s.getChildren()[1], 0);
		if (s.getChildren()[1]!=null) {
			s.getChildren()[1].setParent(u);
		}
		
		s.setChild(r, 0);
		if (r!=null) {
			r.setParent(s);
		}

		s.setChild(u, 1);
		if (u!=null) {
			u.setParent(s);
		}
		
		adjNode=s;
		return adjNode;
	}
	//�ұߵ���ת
	public Node rSingleRotation(Node adjNode) {
		
		System.out.println("�ұߵ���ת");
		System.out.println("adjNode.id="+adjNode.getId());
		Node u=adjNode;
		Node r=adjNode.getChildren()[1];

		u.setChild(r.getChildren()[0], 1);
		if (r.getChildren()[0]!=null) {
			r.getChildren()[0].setParent(u);
		}

		r.setChild(u, 0);
		if (u!=null) {
			u.setParent(r);
		}
		
		
		adjNode=r;
		return adjNode;
	}
	//�ұ�˫��ת
	public Node rDoubleRotation(Node adjNode) {
		
		System.out.println("�ұ�˫��ת");
		System.out.println("adjNode.id="+adjNode.getId());
		Node u=adjNode;
		Node r=u.getChildren()[1];
		Node s=r.getChildren()[0];

		u.setChild(s.getChildren()[0], 1);
		if (s.getChildren()[0]!=null) {
			s.getChildren()[0].setParent(u);
		}

		r.setChild(s.getChildren()[1], 0);
		if (s.getChildren()[1]!=null) {
			s.getChildren()[1].setParent(r);
		}

		s.setChild(u, 0);
		if (u!=null) {
			u.setParent(s);
		}

		s.setChild(r, 1);
		if (r!=null) {
			r.setParent(s);
		}
		
		adjNode=s;
		return adjNode;
	}
}
