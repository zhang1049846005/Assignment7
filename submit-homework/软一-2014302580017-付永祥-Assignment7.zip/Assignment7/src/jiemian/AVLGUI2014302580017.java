package jiemian;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTree;

import dataStruct.AVLTree;
import dataStruct.Node;

public class AVLGUI2014302580017 {

	private JFrame frame;
	private JTree tree;
	private AVLTree<String> avl;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AVLGUI2014302580017 window = new AVLGUI2014302580017();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AVLGUI2014302580017() {
		initialize();

		loadTree();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 651, 479);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 13, 457, 355);
		frame.getContentPane().add(scrollPane);

		tree = new JTree();
		tree.setFont(new Font("����", Font.PLAIN, 18));
		scrollPane.setViewportView(tree);

		JButton btn_add = new JButton("\u6DFB\u52A0");
		btn_add.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String data = JOptionPane.showInputDialog(frame, "������data");
				int id;
				try{
				id = Integer.parseInt(JOptionPane.showInputDialog(frame, "������id"));
				}catch(NumberFormatException ex){
					JOptionPane.showMessageDialog(frame, "idӦΪ������", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				Node<String> node = new Node<String>(data,id);
				avl.insert(node);
				tree.setModel(avl.treeMode());
			}
		});
		btn_add.setBounds(506, 69, 113, 27);
		frame.getContentPane().add(btn_add);

		JButton btn_del = new JButton("\u5220\u9664");
		btn_del.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int id;
				try{
				id = Integer.parseInt(JOptionPane.showInputDialog(frame, "������Ҫɾ���ڵ��id"));
				}catch(NumberFormatException ex){
					JOptionPane.showMessageDialog(frame, "idӦΪ������", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				avl.delete(id);
				tree.setModel(avl.treeMode());
			}
		});
		btn_del.setBounds(506, 280, 113, 27);
		frame.getContentPane().add(btn_del);
		
		JButton btn_search = new JButton("\u67E5\u627E");
		btn_search.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int id;
				try{
				id = Integer.parseInt(JOptionPane.showInputDialog(frame, "������Ҫ���ҽڵ��id"));
				}catch(NumberFormatException ex){
					JOptionPane.showMessageDialog(frame, "idӦΪ������", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				Node<String> node = avl.get(id);
				if(node == null) {
					JOptionPane.showMessageDialog(frame, "δ�ҵ������¼", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				JOptionPane.showMessageDialog(frame, node.toString(), "��ϸ��Ϣ", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btn_search.setBounds(506, 179, 113, 27);
		frame.getContentPane().add(btn_search);
		
	}

	private void loadTree() {
		avl = new AVLTree<String>(frame);
		File file = new File("tree_data.dat");
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
			String line = br.readLine();
			while(line!=null){
				//System.out.println(line);
				String[] s = line.split("#");
				Node<String> node = new Node<String>(s[0],Integer.parseInt(s[1]));
				avl.insert(node);
				line = br.readLine();
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(frame, "���ݶ�ȡʧ��", "Error", JOptionPane.ERROR_MESSAGE); 
			//e.printStackTrace();
		}
		
		tree.setModel(avl.treeMode());
	}

	private void test() {
		// ��������
		/*
		   AVLTree<Integer> avl = new AVLTree<Integer>(50,50); int[] nums = new
		   int[80];
		   
		   for(int i=0;i<nums.length;i++) { nums[i] = new Random().nextInt(100);
		   System.out.println("����nums["+i+"]="+nums[i]+"��"); avl.insert(new
		   Node<Integer>(nums[i],nums[i]));
		   
		   }
		   
		   
		   System.out.print("nums["); for(int i=0;i<nums.length;i++)
		   System.out.print(nums[i]+","); System.out.println("]");
		   
		  
		   for(int i=0;i<nums.length/2;i++){ int num = Math.max(new
		   Random().nextInt(5) - 1,0); System.out.println("Deleting "
		   +nums[num]); avl.delete(nums[num]); }
		   
		   
		   tree.setModel(avl.treeMode());
		 */
	}
}
