package dataStruct;

import java.awt.Component;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class AVLTree<E> implements IAVLTree<E> {
	private Node<E> root;
	private Component comp;

	public Node<E> getRoot() {
		return root;
	}

	public AVLTree(Component comp) {
		this.comp = comp;
		root = null;
	}

	public AVLTree(Component comp,E n, int id) {
		this.comp = comp;
		root = new Node<E>(n, id);
	}

	@Override
	public Node<E> get(int id) {
		// TODO Auto-generated method stub

		Node<E> p = root;
		while (p != null) {
			if (p.getId() > id)
				p = p.getlChild();
			else if (p.getId() < id)
				p = p.getrChild();
			else
				return p;
		}

		// �޴�id��¼
		return null;
	}

	@Override
	public void insert(Node<E> newNode) {
		// TODO Auto-generated method stub
		if (root == null) {
			root = new Node<E>(newNode.getData(),newNode.getId());
			return;
		}

		Node<E> parent = root;

		while (true) {
			if (parent.getId() > newNode.getId()) {
				if (parent.getlChild() != null)
					parent = parent.getlChild();
				else {
					newNode.setParent(parent);
					parent.setlChild(newNode);
					// ��ת������
					break;
				}
			} else if (parent.getId() < newNode.getId()) {
				if (parent.getrChild() != null)
					parent = parent.getrChild();
				else {
					newNode.setParent(parent);
					parent.setrChild(newNode);
					// ��ת������
					break;
				}
			} else {
				// id�����������ظ�
				//System.out.println("�ظ�");
				JOptionPane.showMessageDialog(comp, "������������ԭ�����ݳ�ͻ", "����ʧ��", JOptionPane.WARNING_MESSAGE);
				return;
			}

		}

		// ����height,ȷ����ת����
		Node<E> p = newNode.getParent();
		Node<E> pson = newNode;
	
		while (p != null) {
			if (p.getlChild() == pson) {// psonΪp��ڵ�

				p.setlSubTreeHeight(Math.max(pson.getlSubTreeHeight(), pson.getrSubTreeHeight()) + 1);

			} else {// psonΪp�ҽڵ�

				p.setrSubTreeHeight(Math.max(pson.getlSubTreeHeight(), pson.getrSubTreeHeight()) + 1);

			}

			if (p.getBalanceFactor() < -1 || p.getBalanceFactor() > 1)
				break;
			pson = p;
			p = p.getParent();

		}

		if (p == null) { // ����Ҫ��ת
			// System.out.println(newNode.getData() + "����Ҫ��ת���ɹ�");
			return;
		} else {
			rotate(p);
			
		}

	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node<E> node = get(id);
		Node<E> p = null;
		if (node == null) {
			// �޴����¼
			//System.out.println("�޼�¼" + id);
			JOptionPane.showMessageDialog(comp, "δ�ҵ���������", "ɾ��ʧ��", JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (node.getlChild() == null && node.getrChild() == null) {// ΪҶ��
			delete(node);
			return;
		}

		if (node.getlChild() != null && (node.getlChild().getrChild() != null
				|| (node.getlChild().getlChild() == null && node.getlChild().getrChild() == null))) {
			p = node.getlChild().getrChild();
			if (p != null)
				while (true) {
					if (p.getrChild() != null)
						p = p.getrChild();
					else if (p.getlChild() != null)
						p = p.getlChild();
					else
						break;
				}
			else{
				p = node.getlChild();
				if(p.getlChild() != null) p = null;
			}
		}
		if (p == null && node.getrChild() != null && (node.getrChild().getlChild() != null
				|| (node.getrChild().getlChild() == null && node.getrChild().getrChild() == null))) {// ֱ��ǰ���ǽڵ�
			p = node.getrChild().getlChild();
			if (p != null)
				while (true) {
					if (p.getlChild() != null)
						p = p.getlChild();
					else if (p.getrChild() != null)
						p = p.getrChild();
					else
						break;
				}
			else{
				p = node.getrChild();
				if(p.getrChild() != null) p = null;
			}
		}

		if (p == null) {// ǰ���ͺ�̾�Ϊ�ڵ㡣����
			p = node.getlChild();
			if (node.getrChild() != null) 
				node.getrChild().setParent(p);
			p.setrChild(node.getrChild());
			if(node == root) root = p;
			
			return;
		}

		node.setData(p.getData());
		node.setID(p.getId());
		delete(p);

	}

	/*
	 * delNode must be a left of the tree
	 */
	private void delete(Node<E> delNode) {
		Node<E> father = delNode.getParent();
		if (father == null) {// Ҫɾ������ֻ��root�ڵ�
			root = null;
			return;
		}

		if (father.getlChild() == delNode){
			father.setlChild(null);
			father.setlSubTreeHeight(0);
		}
			
		else{
			father.setrChild(null);
			father.setrSubTreeHeight(0);
		}
		delNode.setParent(null);

		Node<E> p = father.getParent();
		Node<E> pson = father;

		// ɾ�������ı��˸߶�
		if (pson.getlChild() == null && pson.getrChild() == null) {

			while (p != null) {
				// �޸�p�����߶�
				if (p.getlChild() == pson)
					p.setlSubTreeHeight(Math.max(pson.getlSubTreeHeight(), pson.getrSubTreeHeight()) + 1);
				else
					p.setrSubTreeHeight(Math.max(pson.getlSubTreeHeight(), pson.getrSubTreeHeight()) + 1);

				if (p.getBalanceFactor() < -1 || p.getBalanceFactor() > 1)
					break;
				
				
				pson = p;
				p = p.getParent();
			}
			
		} else {
			p = father;
			if (p.getlChild() != null)
				pson = p.getlChild();
			else
				pson = p.getrChild();
			if(pson.getlChild() == null && pson.getrChild() == null) return;//����Ҫ��ת
		}
		if (p == null) {// ����Ҫ��ת
			return;
		}

		rotate(p);

	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		return new JTree(treeMode());
	}

	public DefaultTreeModel treeMode() {
		if(root == null) return new DefaultTreeModel(new DefaultMutableTreeNode("Empty tree"));
		DefaultMutableTreeNode rt = new DefaultMutableTreeNode(root.getData() + " id(" + root.getId() + ")"+" BR="+root.getBalanceFactor());
		DefaultMutableTreeNode tn;

		Queue<Node<E>> q = new LinkedList<Node<E>>();
		q.add(root);
		while (!q.isEmpty()) {
			Node<E> p = q.poll();
			if (p.getlChild() != null)
				p = p.getlChild();
			if (p.getrChild() != null)
				p = p.getrChild();
		}

		Queue<Node<E>> queue = new LinkedList<Node<E>>();
		root.setMtd(rt);
		queue.add(root.getlChild());
		queue.add(root.getrChild());

		while (!queue.isEmpty()) {
			Node<E> p = queue.poll();
			if (p == null)
				continue;
			tn = new DefaultMutableTreeNode(
					p.getData() + " id(" + p.getId() + ") " + (p.getParent().getlChild() == p ? "��" : "��") + " BR="+p.getBalanceFactor());
			p.setMtd(tn);
			p.getParent().getMtd().add(tn);

			if (p.getlChild() != null)
				queue.add(p.getlChild());
			if (p.getrChild() != null)
				queue.add(p.getrChild());
		}

		return new DefaultTreeModel(rt);
	}

	private void rotate(Node<E> p) {
		Node<E> pson;
		if (p.getBalanceFactor() == 2) {
			pson = p.getlChild();
			if (pson.getlSubTreeHeight() < pson.getrSubTreeHeight())
				LR(p);
			else
				LL(p);// ��ʹpson.getBalance=0,LLҲ����ʹ֮ʧ��
		} else {// p.getBalanceFactor() == -2
			pson = p.getrChild();
			if (pson.getlSubTreeHeight() > pson.getrSubTreeHeight())
				RL(p);
			else
				RR(p);// ��ʹpson.getBalance=0,LLҲ����ʹ֮ʧ��
		}
	}

	private void LL(Node<E> A) {
		Node<E> B = A.getlChild();
		Node<E> C = B.getrChild();

		// B ���� A ��λ��
		B.setParent(A.getParent());
		if (A == root) {
			root = B;
		} else if (A.getParent().getlChild() == A) {// AΪ������
			B.getParent().setlChild(B);
		} else {// AΪ������
			B.getParent().setrChild(B);
		}

		// C��ΪA��������
		A.setlChild(C);
		if (C != null)
			C.setParent(A);
		// A��ΪB��������
		A.setParent(B);
		B.setrChild(A);

		// ���¸߶�����
		A.setlSubTreeHeight(B.getrSubTreeHeight());
		B.setrSubTreeHeight(Math.max(A.getlSubTreeHeight(), A.getrSubTreeHeight()) + 1);

	}

	private void RR(Node<E> A) {

		Node<E> B = A.getrChild();
		Node<E> C = B.getlChild();

		// B ���� A ��λ��
		B.setParent(A.getParent());
		if (A == root) {
			root = B;
		} else if (A.getParent().getlChild() == A) {// AΪ������
			B.getParent().setlChild(B);
		} else {// AΪ������
			B.getParent().setrChild(B);
		}

		// C��ΪA��������
		A.setrChild(C);
		if (C != null)
			C.setParent(A);
			
		// A��ΪB��������
		A.setParent(B);
		B.setlChild(A);

		// ���¸߶�����
		A.setrSubTreeHeight(B.getlSubTreeHeight());
		B.setlSubTreeHeight(Math.max(A.getlSubTreeHeight(), A.getrSubTreeHeight()) + 1);
	}

	private void LR(Node<E> A) {
		Node<E> B = A.getlChild();
		Node<E> C = B.getrChild();

		// C ���� A ��
		C.setParent(A.getParent());
		if (A == root) {
			root = C;
		} else if (A == A.getParent().getrChild())
			A.getParent().setrChild(C);
		else
			A.getParent().setlChild(C);

		// C����������ΪB��������
		B.setrSubTreeHeight(C.getlSubTreeHeight());
		B.setrChild(C.getlChild());
		if (C.getlChild() != null)
			C.getlChild().setParent(B);

		// C����������ΪA��������
		A.setlSubTreeHeight(C.getrSubTreeHeight());
		A.setlChild(C.getrChild());
		if (C.getrChild() != null)
			C.getrChild().setParent(A);

		// B ��Ϊ C ��������
		C.setlChild(B);
		B.setParent(C);

		// A ��Ϊ C ��������
		C.setrChild(A);
		A.setParent(C);

		//���¸߶�
		C.setlSubTreeHeight(1 + Math.max(B.getlSubTreeHeight(), B.getrSubTreeHeight()));
		C.setrSubTreeHeight(1 + Math.max(A.getlSubTreeHeight(), A.getrSubTreeHeight()));
	}

	private void RL(Node<E> A) {
		Node<E> B = A.getrChild();
		Node<E> C = B.getlChild();

		// C ���� A ��
		C.setParent(A.getParent());
		if (A == root) {
			root = C;
		} else if (A.getParent().getrChild() == A)
			A.getParent().setrChild(C);
		else
			A.getParent().setlChild(C);

		// C����������ΪB��������
		B.setlSubTreeHeight(C.getrSubTreeHeight());
		B.setlChild(C.getrChild());
		if (C.getrChild() != null)
			C.getrChild().setParent(B);

		// C����������ΪA��������
		A.setrSubTreeHeight(C.getlSubTreeHeight());
		A.setrChild(C.getlChild());
		if (C.getlChild() != null)
			C.getlChild().setParent(A);

		// B ��Ϊ C ��������
		C.setrChild(B);
		B.setParent(C);

		// A ��Ϊ C ��������
		C.setlChild(A);
		A.setParent(C);

		C.setlSubTreeHeight(1 + Math.max(A.getlSubTreeHeight(), A.getrSubTreeHeight()));
		C.setrSubTreeHeight(1 + Math.max(B.getlSubTreeHeight(), B.getrSubTreeHeight()));

	}
}
