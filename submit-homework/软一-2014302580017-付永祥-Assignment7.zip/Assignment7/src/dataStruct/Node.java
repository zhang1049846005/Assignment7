package dataStruct;

import javax.swing.tree.DefaultMutableTreeNode;

public class Node<E> {
	private int id;
	private E data;
	private Node<E> parent;
	private Node<E> lChild,rChild;
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	private DefaultMutableTreeNode mtd;
	
	public DefaultMutableTreeNode getMtd() {
		return mtd;
	}

	public void setMtd(DefaultMutableTreeNode mtd) {
		this.mtd = mtd;
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder("<html><body> ");
		result.append("data = "+data+"<br>");
		result.append("id = "+id+"<br>");
		result.append((parent == null? "" :"parent data="+parent.getData()+"</br>"));
		result.append((lChild == null? "" :"left Child data = "+lChild.getData()+"<br>"));
		result.append((rChild == null? "" :"right Child data = "+rChild.getData()+"<br>"));
		result.append("left height = "+lSubTreeHeight+"<br>");
		result.append("right height = "+rSubTreeHeight+"<br>");
		result.append("Balance Factor = "+balanceFactor+"<br>");
		/*return "Node [ 
				+ ", lSubTreeHeight=" + lSubTreeHeight + ", rSubTreeHeight=" + rSubTreeHeight + ", balanceFactor="
				+ balanceFactor + "]";*/
		result.append(" </html></body>");
		return result.toString();
	}

	public Node(E n,int id){
		data = n;
		this.id = id;
		lChild = null;
		rChild = null;
		lSubTreeHeight = 0;
		rSubTreeHeight = 0;
		balanceFactor = 0;
		parent = null;
		mtd = null;
	}
	
	public int getId() {
		return id;
	}
	public void setID(int id){
		this.id = id;
	}
	public E getData() {
		return data;
	}
	public void setData(E data) {
		this.data = data;
	}
	public Node<E> getParent() {
		return parent;
	}
	public void setParent(Node<E> parent) {
		this.parent = parent;
	}
	
	public Node<E> getlChild() {
		return lChild;
	}
	public void setlChild(Node<E> lChild) {
		this.lChild = lChild;
	}
	public Node<E> getrChild() {
		return rChild;
	}
	public void setrChild(Node<E> rChild) {
		this.rChild = rChild;
	}
	public void setlSubTreeHeight(int lSubTreeHeight){
		this.lSubTreeHeight = lSubTreeHeight;
		//ˢ��balanceFactor;
		this.balanceFactor = this.lSubTreeHeight - this.rSubTreeHeight;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		return lSubTreeHeight;
	}
	public void setrSubTreeHeight(int rSubTreeHeight){
		this.rSubTreeHeight = rSubTreeHeight;
		//ˢ��balanceFactor;
		this.balanceFactor = this.lSubTreeHeight - this.rSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		return rSubTreeHeight;
	}
	
	public void setBlanceFactor(int balanceFactor){
		this.balanceFactor = balanceFactor;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return balanceFactor;
	}
	

}
