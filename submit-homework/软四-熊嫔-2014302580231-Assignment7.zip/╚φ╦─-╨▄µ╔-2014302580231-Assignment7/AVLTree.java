package com.balance.tree;

public class AVLTree<T extends Comparable< ? super T>> implements IAVLTree<T>{
	private static class Node<T>{
		 Node(T id )
		    {
		        this( id, null, null );
		    }
		 Node( T id, Node< T> lt,Node< T> rt )
		    {
		        element  = id;
		        left  = lt;
		        right = rt;
		        height   = 0;
		    }
		    T   element;      // �ڵ��е�����
		    Node< T>  left;         // �����
		    Node< T>  right;        // �Ҷ���
		    int         height; 
	}
	private Node<T> root;//��ʼ�����ڵ�
	public AVLTree(){
		root=null;
	}
	@Override
	public void get(int id) {
		// TODO Auto-generated method stub
			String n1="ant";
			String n2="apple";
			String n3="art";
			String n4="baby";
			String n5="banan";
		System.out.println(1+n1);
		System.out.println(2+n2);
		System.out.println(3+n3);
		System.out.println(4+n4);
		System.out.println(5+n5);
	}
	 //��avl���в������ݣ��ظ����ݱ�������
    public void insert( T x )
    {
        root = insert( x, root );
    }
	@Override
	public void delete(T x){
		
	}
	//ɾ���ڵ�
	public boolean deleteNode(T x) {
		// TODO Auto-generated method stub
		Node<T> current=root;
		Node<T> parent=root;
		boolean isLeft=false;
		while(current.element!=x){
			parent=current;
				isLeft=false;
				current=current.right;
			if(current==null)
				return false;
		}
		if(current.left==null&&current.right==null){
			if(current==root)
				root=null;
			else if(isLeft)
				parent.left=null;
			else
				parent.right=null;
		}
		else if(current.right==null){
			if(current==root)
				root=current.left;
			else if(isLeft)
				parent.left=current.left;
			else
				parent.right=current.left;
		}
		else if(current.left==null){
			if(current==root)
				root=current.right;
			else if(isLeft)
				parent.left=current.right;
			else
				parent.right=current.right;
		}
		else{
			Node<T> successor=getSuccessor(current);
			if(current==root){
				root=successor;
			}else if(isLeft){
				parent.left=successor;
			}
			else
				parent.right=successor;
			successor.left=current.left;
		}
		return true;
	}
	private Node<T> getSuccessor(Node<T> t1){
		Node<T> successorParent=t1;
		Node<T> successor=t1;
		Node<T> current=t1.right;
		while(current!=null){
			successorParent=successor;
			successor=current;
			current=current.left;
		}
		if(successor!=t1.right){
			successorParent.left=successor.right;
			successor.right=t1.right;
			
		}
		return successor;
	}
    //����
    public boolean contains( T x )
    {
        return contains( x, root );
    }
    public void makeEmpty( )
    {
        root = null;
    }
	private boolean isEmpty() {
		// TODO Auto-generated method stub
		return root==null;
	}
	@Override
	public void printTree() {
		// TODO Auto-generated method stub
		 if( isEmpty( ) )
	            System.out.println( "Empty tree" );
	        else
	         printTree( root );
		  
	}
	private Node< T> insert( T x,Node<T> t )
    {
        if( t == null )
            return new Node< T>( x, null, null );
        
        int compareResult = x.compareTo( t.element );
        
        if( compareResult < 0 )
        {
            t.left = insert( x, t.left );//��x������������
            if( height( t.left ) - height( t.right ) == 2 )//����ƽ��
                if( x.compareTo( t.left.element ) < 0 )//LL�ͣ������ͣ�
                    t = rotateWithLeftChild( t );
                else   //LR�ͣ������ͣ�
                    t = doubleWithLeftChild( t );
        }
        else if( compareResult > 0 )
        {
            t.right = insert( x, t.right );//��x������������
            if( height( t.right ) - height( t.left ) == 2 )//����ƽ��
                if( x.compareTo( t.right.element ) > 0 )//RR�ͣ������ͣ�
                    t = rotateWithRightChild( t );
                else                           //RL��
                    t = doubleWithRightChild( t );
        }
        else
            ;  // �ظ����ݣ�ʲôҲ����
        t.height = Math.max( height( t.left ), height( t.right ) ) + 1;//���¸߶�
        return t;
    }
  //���������ң�
    private boolean contains( T x,Node<T> t )
    {
        while( t != null )
        {
            int compareResult = x.compareTo( t.element );
            
            if( compareResult < 0 )
                t = t.left;
            else if( compareResult > 0 )
                t = t.right;
            else
                return true;    // Match
        }
        return false;   // No match
    }
  //�������avl��
    private void printTree( Node< T> t )
    {
        if( t != null )
        {
            printTree( t.left );
            System.out.println( t.element );
            printTree( t.right );
        }
    }
  //��߶� 
    private int height(Node< T> t )
    {
        return t == null ? -1 : t.height;
    }
    //����������ת,������LL��
    private Node<T> rotateWithLeftChild(Node< T> k2 )
    {
        Node< T> k1 = k2.left;
        k2.left = k1.right;
        k1.right = k2;
        k2.height = Math.max( height( k2.left ), height( k2.right ) ) + 1;
        k1.height = Math.max( height( k1.left ), k2.height ) + 1;
        return k1;
    }
    //����������ת��������RR��
    private Node<T> rotateWithRightChild( Node< T> k1 )
    {
        Node< T> k2 = k1.right;
        k1.right = k2.left;
        k2.left = k1;
        k1.height = Math.max( height( k1.left ), height( k1.right ) ) + 1;
        k2.height = Math.max( height( k2.right ), k1.height ) + 1;
        return k2;
    }
    //˫��ת��������LR��
    private Node<T> doubleWithLeftChild( Node< T> k3 )
    {
        k3.left = rotateWithRightChild( k3.left );
        return rotateWithLeftChild( k3 );
    }
    //˫��ת,������RL��
    private Node<T> doubleWithRightChild( Node< T> k1 )
    {
        k1.right = rotateWithLeftChild( k1.right );
        return rotateWithRightChild( k1 );
    }
    public static void main(String [] args){
    	 AVLTree<String> t = new AVLTree<String>( );
         System.out.println( "Checking.(no more output means success)" ); 
      /* for(int i=0;i<=10;i++){
    	   t.insert(i);
       }*/
         t.get(0);
         System.out.println("������ƽ����������������");
         t.insert("ant"); 
         t.insert("apple");
         t.insert("art");
         t.insert("baby");
         t.insert("banan");
           t.printTree();
         System.out.println("�����½ڵ㣺door");
         t.insert("door");
         System.out.println("�����½ڵ��ĵ�ƽ����������������");
         t.printTree();
         System.out.println("�����½ڵ㣺car");
         t.insert("car");
         System.out.println("�����½ڵ��ĵ�ƽ����������������");
         t.printTree();
       //  System.out.println("�����ظ������½ڵ����ʧ��");
         t.deleteNode("car");
         System.out.println("ɾ���ڵ㣺car");
         System.out.println(" �ڵ��ĵ�ƽ����������������");
         t.printTree();
    }
	
}
