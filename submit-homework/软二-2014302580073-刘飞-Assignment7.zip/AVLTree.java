import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
public class AVLTree implements IAVLTree
{
	public Node root;
	private boolean unBalance;

	public Node order(Node t,int id)
	{
		if(t!=null)
		{
			if(t.getId()==id)
			{
				return t;
			}
			else
			{
				if(t.getId()>id)
				{
					return order(t.getChildren()[0],id);
				}
				else
				{
					return order(t.getChildren()[1],id);
				}
				
			}
			
		}
		return null;
	}
	@Override
	public Node get(int id) 
	{
		// TODO �Զ����ɵķ������
		
		return order(root,id);
	}
	public void LRotation(Node s)
	{
		Node u,r=s.getChildren()[0];
		if(r.getBalanceFactor()==1)
		{
			s.setChild(r.getChildren()[1], 0);
			r.setChild(s, 1);
			s=r;
		}
		else
		{
			u=r.getChildren()[1];
			r.setChild(u.getChildren()[0], 1);
			u.setChild(r, 0);
			s.setChild(u.getChildren()[1],0);
			u.setChild(s, 1);
			s=u;
		}
		unBalance=false;
	}
	public void RRotation(Node s)
	{
		Node u,r=s.getChildren()[1];
		if(r.getBalanceFactor()==-1)
		{
			s.setChild(r.getChildren()[0], 1);
			if(r.getChildren()[0]!=null)
			{			
				r.getChildren()[0].setParent(s);
			}
			r.setParent(null);
			r.setChild(null, 0);

			r.setChild(s, 0);
		
			if(s.getParent()!=null)
			{
				if(s.getParent().getChildren()[0]==s)
				{
					r.setParent(s.getParent());
					s.getParent().setChild(r, 0);
				}else
				{
					r.setParent(s.getParent());
					s.getParent().setChild(r, 1);
				}
			}else
			{
				root=r;
			}
			s.setParent(r); 
		}
		else if(r.getBalanceFactor()==1)
		{
			u=r.getChildren()[0];
			r.setChild(u.getChildren()[1], 0);
			if(u.getChildren()[1]!=null)
			{
				u.getChildren()[1].setParent(r);
			}
			u.setChild(null, 1);
			u.setParent(null);
			
			
			s.setChild(u.getChildren()[0], 1);			
			r.setParent(null);
			u.getChildren()[0].setParent(s);
			u.setChild(null, 0);
			
			u.setChild(r, 1);
			u.setChild(s, 0);

			if(s.getParent()!=null)
			{
				if(s.getParent().getChildren()[0]==s)
				{
					u.setParent(s.getParent());
					s.getParent().setChild(u, 0);
				}else
				{
					u.setParent(s.getParent());
					s.getParent().setChild(u, 1);
				}
			}
			else
			{
				root=u;
			}
			s.setParent(u);
			r.setParent(u);
		}
		unBalance=false;
	}
	public void insert(Node p,Node newNode)
	{
		
		if(newNode.getId()<p.getId())
		{
			
			if(p.getChildren()[0]==null)
			{
				p.setChild(newNode, 0);
				newNode.setParent(p);
			}
			else
				insert(p.getChildren()[0],newNode);
			
			
			if(p.getBalanceFactor()==1)
			{
				if(p.getParent()!=null)
				{
					if(p.getParent().getBalanceFactor()>1||p.getParent().getBalanceFactor()<-1)
						LRotation(p.getParent());
				}
			}
		
			
		}
		else if(newNode.getId()==p.getId())
		{
			JOptionPane.showMessageDialog( null,"�ýڵ�"+newNode+"�Ѵ���" ,
					  "error", JOptionPane.PLAIN_MESSAGE );		
		}
		else if(newNode.getId()>p.getId())
		{
			
			if(p.getChildren()[1]==null)
			{
				p.setChild(newNode, 1);
				newNode.setParent(p);
			}
			else
				insert(p.getChildren()[1],newNode);
			
			
			
			if(p.getBalanceFactor()==-1)
			{
				if(p.getParent()!=null)
				{
					if(p.getParent().getBalanceFactor()>1||p.getParent().getBalanceFactor()<-1)
						RRotation(p.getParent());
				} 
			}
			
		}
	}

	@Override
	public void insert(Node newNode) 
	{
		// TODO �Զ����ɵķ������
		if(root==null)
		{
			root=newNode;
		}
		else
			insert(root,newNode);
	
	}
	private void delete(Node temp)
	{
		if(temp.getParent().getChildren()[0]==temp)
		{					
			if(temp.getChildren()[0]!=null)
			{
				temp.getChildren()[0].setParent(temp.getParent());
				temp.getParent().setChild(temp.getChildren()[0], 0);
				temp=temp.getChildren()[0];
			}
			else if(temp.getChildren()[1]!=null)
			{
				temp.getChildren()[1].setParent(temp.getParent());
				temp.getParent().setChild(temp.getChildren()[1], 0);
				temp=temp.getChildren()[1];
			}
			else
			{
				temp=temp.getParent();
				temp.setChild(null, 0);
			}	
		}
		else if(temp.getParent().getChildren()[1]==temp)
		{
			if(temp.getChildren()[0]!=null)
			{
				temp.getChildren()[0].setParent(temp.getParent());
				temp.getParent().setChild(temp.getChildren()[0], 1);
				temp=temp.getChildren()[0];
			}
			else if(temp.getChildren()[1]!=null)
			{
				temp.getChildren()[1].setParent(temp.getParent());
				temp.getParent().setChild(temp.getChildren()[1], 1);
				temp=temp.getChildren()[1];
			}
			else
			{
				temp=temp.getParent();
				temp.setChild(null, 1);
			}
		}
	};

	@Override
	public void delete(int id) 
	{
		
		Node temp=get(id);
		if(temp!=null)
		{
			if(temp.getChildren()[0]!=null&&temp.getChildren()[1]!=null)
			{
				Node next=null;
				int nextId=id+1;
				while(next==null)
				{
					next=get(nextId);
					nextId++;
				}
				temp.setId(next.getId());
				temp.setData(next.getData());
				id=nextId;
				temp=next;
			}		
			if(temp==root)
			{
				
				if(root.getChildren()[0]!=null)
				{
					root.getChildren()[0].setParent(null);
					root=root.getChildren()[0];
				}
				else if(root.getChildren()[1]!=null)
				{	
					root.getChildren()[1].setParent(null);
					root=root.getChildren()[1];
				}
				
			}
			else if(temp!=null)
			{			
				if(temp.getParent().getBalanceFactor()==0)
				{
					delete(temp);
				}
				
				if(temp.getParent().getBalanceFactor()==1&&temp.getParent().getChildren()[0]==temp)
				{
					delete(temp);
					while(temp.getParent().getBalanceFactor()<=1&&temp.getParent().getBalanceFactor()>=-1)
					{
						temp=temp.getParent();	
						if(temp.getParent()==null)
							break;									
					}
					
					if(temp.getParent()!=null)
					{
						if(temp.getParent().getBalanceFactor()==-2)
							RRotation(temp.getParent());
						else if(temp.getParent().getBalanceFactor()==2)
							LRotation(temp.getParent());
					}
						
				}
				else if(temp.getParent().getBalanceFactor()==-1&&temp.getParent().getChildren()[1]==temp)
				{
					delete(temp);
					while(temp.getParent().getBalanceFactor()<=1&&temp.getParent().getBalanceFactor()>=-1)
					{
						temp=temp.getParent();	
						if(temp.getParent()==null)
							break;									
					}
					
					if(temp.getParent()!=null)
					{
						if(temp.getParent().getBalanceFactor()==-2)
							RRotation(temp.getParent());
						else if(temp.getParent().getBalanceFactor()==2)
							LRotation(temp.getParent());
					}
				}
				
				if(temp.getParent().getBalanceFactor()==1&&temp.getParent().getChildren()[1]==temp)
				{
					delete(temp);
					while(temp.getParent().getBalanceFactor()<=1&&temp.getParent().getBalanceFactor()>=-1)
					{
						temp=temp.getParent();	
						if(temp.getParent()==null)
							break;									
					}
					
					if(temp.getParent()!=null)
					{
						if(temp.getParent().getBalanceFactor()==-2)
							RRotation(temp.getParent());
						else if(temp.getParent().getBalanceFactor()==2)
							LRotation(temp.getParent());
					}
						
				}
				else if(temp.getParent().getBalanceFactor()==-1&&temp.getParent().getChildren()[0]==temp)
				{
					delete(temp);
					while(temp.getParent().getBalanceFactor()<=1&&temp.getParent().getBalanceFactor()>=-1)
					{
						temp=temp.getParent();	
						if(temp.getParent()==null)
							break;									
					}
					
					if(temp.getParent()!=null)
					{
						if(temp.getParent().getBalanceFactor()==-2)
							RRotation(temp.getParent());
						else if(temp.getParent().getBalanceFactor()==2)
							LRotation(temp.getParent());
					}
				}
			}
		}
	}

	@Override
	public JTree printTree()
	{
		
		return new JTree(buildJTree(this.root));
	}
	private DefaultMutableTreeNode buildJTree(Node node){
		if(node==null){
			return null;
		}
		DefaultMutableTreeNode left=buildJTree(node.getChildren()[0]);
		DefaultMutableTreeNode right=buildJTree(node.getChildren()[1]);
		DefaultMutableTreeNode treeNode=new DefaultMutableTreeNode(node.getData().toString()
				+"("+node.getId()+")");
		if(left!=null){
			treeNode.add(left);
		}
		if(right!=null){
			treeNode.add(right);
		}
		return treeNode;
	}

}
