import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTree;

public class Main 
{

	public static void main(String[] args) 
	{
		

		AVLTree avl=new AVLTree();
		
		Node a=new Node();
		a.setId(1);
		a.setData("num1");
		Node b=new Node();
		b.setId(2);	
		b.setData("num2");
		Node c=new Node();
		c.setId(3);
		c.setData("num3");
		Node d=new Node();
		d.setId(4);
		d.setData("num4");
		Node e=new Node();
		e.setId(5);
		e.setData("num5");
		Node f=new Node();
		f.setId(6);
		f.setData("num6");

		avl.insert(a);
		avl.insert(b);
		avl.insert(c);
		avl.insert(d);
		avl.insert(e);
		avl.insert(f);
		
		System.out.println(avl.get(1));	
		
		JTree showTree=avl.printTree();
		DFrame df=new DFrame(showTree);
		df.setVisible(true);
		df.setSize(500, 500);
		
		df.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JOptionPane.showMessageDialog( null,"���ɵ�AVL��ͼ��ʾ" ,
				  "��ʾ", JOptionPane.PLAIN_MESSAGE );
		JOptionPane.showMessageDialog( null,"��������ɾ������,ɾ��id��2" ,
				  "ɾ��", JOptionPane.PLAIN_MESSAGE );
	
		avl.delete(2);
		
		showTree=avl.printTree();
		df.setTree(showTree);
		df.repaint();
		JOptionPane.showMessageDialog( null,"ɾ�������ɹ�" ,
				  "��ʾ", JOptionPane.PLAIN_MESSAGE );
	}
}
