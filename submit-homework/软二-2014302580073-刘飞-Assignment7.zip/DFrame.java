import javax.swing.JFrame;
import javax.swing.JTree;

public class DFrame extends JFrame
{
	private JTree tree;
	private JTree AfterDeleteTree;
	public void setTree(JTree tree)
	{
		this.AfterDeleteTree=tree;
		this.add(this.AfterDeleteTree);
		this.tree.setVisible(false);
	}
	public DFrame(JTree tree)
	{
		this.tree=tree;
		this.add(this.tree);
	}
}
