public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public int getId() {
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	/*public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		return getSubTreeHeight(this.children[0]);
	}*/
	public int getlSubTreeHeight()
	{
		/*if (t==null) return 0;
		else
		{
			if (getSubTreeHeight(t.children[0])>getSubTreeHeight(t.children[1]))
				return getSubTreeHeight(t.children[0])+ 1;
			else
			{
				return getSubTreeHeight(t.children[1]) + 1;
			}
		}*/
		if(this.getChildren()[0]==null)
			lSubTreeHeight=0;
		else if(this.getChildren()[0]!=null)
		{
			//ͨ���ݹ����߶�
			if(this.getChildren()[0].getlSubTreeHeight()>this.getChildren()[0].getrSubTreeHeight())
				lSubTreeHeight=this.getChildren()[0].getlSubTreeHeight()+1;
			else
				lSubTreeHeight=this.getChildren()[0].getrSubTreeHeight()+1;	
		}
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		//ͨ���ݹ����߶�
		if(this.getChildren()[1]==null)
			rSubTreeHeight=0;
		else if(this.getChildren()[1]!=null)
		{
			if(this.getChildren()[1].getlSubTreeHeight()>this.getChildren()[1].getrSubTreeHeight())
				rSubTreeHeight=this.getChildren()[1].getlSubTreeHeight()+1;
			else
				rSubTreeHeight=this.getChildren()[1].getrSubTreeHeight()+1;
		}
		return rSubTreeHeight;
		
	}
	/*public int getrSubTreeHeight() {
		//TODO calculate the right sub tree heightu7
		return getSubTreeHeight(this.children[1]);
	}*/
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();
		return balanceFactor;
	}
	public void setBanlanceFactor(int balanceFactor)
	{
		this.balanceFactor=balanceFactor;
	}
	public String toString()
	{
		return "id:"+String.valueOf(this.getId())+" data:"+String.valueOf(this.getData());
	}

}
