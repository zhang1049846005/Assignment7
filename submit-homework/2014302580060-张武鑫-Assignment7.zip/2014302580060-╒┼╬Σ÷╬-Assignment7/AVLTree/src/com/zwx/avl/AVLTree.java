package com.zwx.avl;

import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree
{

	private AVLTreei<Integer> tree = new AVLTreei<Integer>();
	@Override
	public Node get(int id) {
		// TODO �Զ����ɵķ������
		return null;
	}

	@Override
	public void insert(int id, Node newNode) {
		// TODO �Զ����ɵķ������
		tree.insert(id);
	}

	@Override
	public void delete(int id) {
		// TODO �Զ����ɵķ������
		tree.remove(id);
	}

	@Override
	public JTree printTree() {
		// TODO �Զ����ɵķ������
		DefaultMutableTreeNode top = new DefaultMutableTreeNode();
		printTree(top,tree.root);
		return new JTree(top);
	}
	
	private void printTree(DefaultMutableTreeNode tnode, Node node)
	{
		if(node==null)
			return;
		DefaultMutableTreeNode cnode = new DefaultMutableTreeNode(node.element);
		tnode.add(cnode);
		printTree(cnode,node.left);
		printTree(cnode,node.right);
		
	}
	
	public static void main(String[] args) {
		AVLTree avlTree = new AVLTree();
		avlTree.insert(100,null);  
	    avlTree.insert(120,null);  
	    avlTree.insert(300,null);  
	    avlTree.insert(500,null); 
	    avlTree.insert(111,null);  
	    avlTree.insert(92,null);  
	    avlTree.insert(77,null);  
	    avlTree.insert(125,null);
	 
	    avlTree.delete(120);
	    avlTree.delete(125);    //��Ҫ����ת    
	    
	    avlTree.insert(78,null);     //��Ҫ˫��ת  
	    
	    System.out.println("Insert Success !");  
		
		JFrame f = new JFrame("JTreeDemo");
        f.add(avlTree.printTree());
        f.setSize(300, 300);
        f.setVisible(true);
	}


}
