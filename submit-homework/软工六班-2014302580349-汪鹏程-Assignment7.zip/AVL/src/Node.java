import java.util.LinkedList;

/**
 * 二叉树节点类
 * 
 * @author wangle
 * 
 * @param <T> 类型参数
 */
public class Node<T> {
	private int id;
	private T data;
	private Node<T> parent;
	private Node<T> leftChild;
	private Node<T> rightChild;

	public Node(){
		this.id=0;
		this.data=null;
		this.parent=null;
		this.leftChild=null;
		this.rightChild=null;
	}

	public Node(int id,T data){
		this.id=id;
		this.data=data;
		this.parent=null;
		this.leftChild=null;
		this.rightChild=null;
	}
	public int getId(){
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public Node<T> getLeftChild() {
		return leftChild;
	}
	public void setLeftChild(Node<T> leftChild) {
		this.leftChild = leftChild;
	}
	public Node<T> getRightChild() {
		return rightChild;
	}
	public void setRightChild(Node<T> rightChild) {
		this.rightChild = rightChild;
	}
	public Node<T> getParent() {
		return parent;
	}
	public void setParent(Node<T> parent) {
		this.parent = parent;
	}

	/**
	 * 偷个懒，平衡因子不自己设置，自动计算
	 * @return 平衡因子
	 */
	public int getBalanceFactor() {
		//计算平衡因子
		return getHeight(this.leftChild)-getHeight(this.rightChild);
	}
	/**
	 * 层次遍历，计算树或者子树的高度，用于计算平衡因子
	 * @param node 树或子树的根节点
	 * @return 高度
	 */
	private int getHeight(Node<T> node){
		if(node==null){
			return 0;
		}
		int visited=0;			//已访问的节点数
		int nodeSum=1;			//存储进过队列的节点数
		int currentLevel=1;		//当前层之前的所有节点数（包括当前层）
		int height=0;
		//LinkedList作为队列
		LinkedList<Node<T>> list=new LinkedList<Node<T>>();
		list.add(node);	//进队列
		while(!list.isEmpty()){
			Node<T> temp = list.poll(); //出队列
			visited++;
			if(temp.getLeftChild()!=null){
				list.add(temp.getLeftChild());
				nodeSum++;
			}
			if(temp.getRightChild()!=null){
				list.add(temp.getRightChild());
				nodeSum++;
			}
			//如果已访问的节点数等于当前层的节点数，则表示一层已经访问完，高度+1，当前层节点树变为队列内节点数
			if(visited==currentLevel){
				height++;
				currentLevel=nodeSum;
			}
		}
		return height;
	}
}
