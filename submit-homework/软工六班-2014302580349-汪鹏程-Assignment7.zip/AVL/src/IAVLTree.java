import javax.swing.JTree;

public interface IAVLTree<T> {
	/**
	 * get the node by index
	 * @param id, the node id to get
	 * @return
	 */
	Node<T> get(int id) throws AVLTreeException;
	/**
	 * insert the node by id
	 */
	void insert(Node<T> newNode)throws AVLTreeException;
	/**
	 * the node id to delete
	 * @param id
	 */
	void delete(int id)throws AVLTreeException;
	/**
	 * print the whole tree
	 * @return a java swing Object JTree
	 */
	JTree printTree();

}
