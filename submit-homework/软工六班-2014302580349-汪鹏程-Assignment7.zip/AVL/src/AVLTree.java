import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 * 平衡二叉树<br>
 * @author wangle
 * @param <T> 节点的数据类型
 */
public class AVLTree<T> implements IAVLTree<T>{
	private Node<T> root;	//根节点
	private int nodeNumber;	//节点数
	/*
	 * 旋转类型
	 */
	private static final int LL=1;
	private static final int RR=2;
	private static final int LR=3;
	private static final int RL=4;

	public AVLTree(){
		root=null;
		nodeNumber=0;
	}
	public AVLTree(Node<T> root){
		this.root=root;
		nodeNumber=0;
	}

	@Override
	public Node<T> get(int id)throws AVLTreeException{
		Node<T> temp=root;
		while(temp!=null){
			if(id<temp.getId()){
				temp=temp.getLeftChild();
			}
			else if(id>temp.getId()){
				temp=temp.getRightChild();
			}
			else{
				break;
			}
		}
		if(temp==null){
			throw new AVLTreeException("The node you are searching isn't exsiting in this AVLTree!");
		}
		return temp;
	}

	@Override
	public void insert(Node<T> newNode)throws AVLTreeException {
		Node<T> temp=root;
		Node<T> pointer=null;//指向newNode的父节点
		while(temp!=null){
			pointer=temp;
			if(newNode.getId()<temp.getId()){
				temp=temp.getLeftChild();
			}
			else if(newNode.getId()>temp.getId()){
				temp=temp.getRightChild();
			}
			else{
				throw new AVLTreeException("The node is already existing in this AVLTree!");
			}
		}
		/*
		 * 插入
		 */
		//如果root为null，即二叉树为空，则newNode作为根节点
		if(root==null){
			this.root=newNode;
		}
		else if(newNode.getId()<pointer.getId()){
			newNode.setParent(pointer);
			pointer.setLeftChild(newNode);
		}
		else{
			newNode.setParent(pointer);
			pointer.setRightChild(newNode);
		}
		//由插入的新节点开始，自下而上调整
		balance(newNode);
		nodeNumber++;
	}

	@Override
	public void delete(int id) throws AVLTreeException{
		Node<T> pointer=root; //指向要删除的节点
		Node<T> replace=null; //替代节点
		while(pointer!=null){
			if(id<pointer.getId()){
				pointer=pointer.getLeftChild();
			}
			else if(id>pointer.getId()){
				pointer=pointer.getRightChild();
			}
			else{
				break;
			}
		}
		if(pointer==null){
			throw new AVLTreeException("The node you are intended to delete isn't existing in this AVLTree");
		}
		//如果要删除的节点两个子树都不为空，则用它的中序后继代替
		if(pointer.getLeftChild()!=null&&pointer.getRightChild()!=null){
			replace=pointer.getRightChild();
			while(replace.getLeftChild()!=null){
				replace=replace.getLeftChild();
			}
			//将id和data替换即可
			pointer.setId(replace.getId());
			pointer.setData(replace.getData());
			//要删除的节点变为中序后继
			pointer=replace;
		}
		/*
		 * 经过以上操作，三种情况
		 * 1、右子树不为空，左子树为空
		 * 2、左子树不为空，右子树为空
		 * 3、右、左子树为空
		 */
		if(pointer.getRightChild()!=null&&pointer.getLeftChild()==null){
			pointer.getRightChild().setParent(pointer.getParent());
			if(pointer.getParent()!=null){
				if(pointer.getRightChild().getId()<pointer.getParent().getId()){
					pointer.getParent().setLeftChild(pointer.getRightChild());
				}
				else{
					pointer.getParent().setRightChild(pointer.getRightChild());
				}
			}
			else{
				pointer.getRightChild().setParent(null);
				root=pointer.getRightChild();
			}
		}
		else if(pointer.getRightChild()==null&&pointer.getLeftChild()!=null){
			pointer.getLeftChild().setParent(pointer.getParent());
			if(pointer.getParent()!=null){
				if(pointer.getLeftChild().getId()<pointer.getParent().getId()){
					pointer.getParent().setLeftChild(pointer.getRightChild());
				}
				else{
					pointer.getParent().setRightChild(pointer.getRightChild());
				}
			}
			else{
				pointer.getLeftChild().setParent(null);
				root=pointer.getLeftChild();
			}
		}
		else{
			if(pointer.getParent()==null){
				//只有一个根节点
				root=null;
				return;
			}
			else if(pointer.getId()<pointer.getParent().getId()){
				pointer.getParent().setLeftChild(null);
			}
			else{
				pointer.getParent().setRightChild(null);
			}
		}
		//从删除的节点开始，自下而上调整整棵二叉树
		balance(pointer);
		nodeNumber--;
	}

	/**
	 * 旋转操作
	 * @param node 最小子树根节点
	 */
	private void rotation(Node<T> node,int type){
		switch(type){
		case AVLTree.LL:
			Node<T> left=node.getLeftChild();
			//如果旋转的节点为根节点，则需要重新设置
			if(node==root){
				root=left;
			}
			left.setParent(node.getParent());
			if(node.getParent()!=null){
				if(node.getParent().getLeftChild()==node){
					node.getParent().setLeftChild(left);
				}
				else{
					//LR旋转专用
					node.getParent().setRightChild(left);
				}
			}
			node.setParent(left);
			if(left.getRightChild()!=null){
				left.getRightChild().setParent(node);
			}
			node.setLeftChild(left.getRightChild());
			left.setRightChild(node);
			break;
		case AVLTree.RR:
			Node<T> right=node.getRightChild();
			if(node==root){
				root=right;
			}
			right.setParent(node.getParent());
			if(node.getParent()!=null){
				if(node.getParent().getRightChild()==node){
					node.getParent().setRightChild(right);
				}
				else{
					//RL旋转专用
					node.getParent().setLeftChild(right);
				}
			}
			node.setParent(right);
			if(right.getLeftChild()!=null){
				right.getLeftChild().setParent(node);
			}
			node.setRightChild(right.getLeftChild());
			right.setLeftChild(node);
			break;
		/*
		 * 双旋转	
		 */
		case AVLTree.LR:
			rotation(node.getLeftChild(),AVLTree.RR);
			rotation(node,AVLTree.LL);
			break;
		case AVLTree.RL:
			rotation(node.getRightChild(),AVLTree.LL);
			rotation(node,AVLTree.RR);
			break;
		default:
			break;
		}
	}
	/**
	 * 从初始节点开始，右下至上，调整整棵二叉树，遇到含不平衡因子的节点，进行旋转
	 * @param node 初始节点
	 */
	private void balance(Node<T> node){
		node=node.getParent();	//指向node节点到根节点的路径上的节点
		Node<T> flag=node;
		//由node节点的父结点开始，依次调整
		while(flag!=null){
			//寻找不平衡的最小子树
			while(node!=null&&Math.abs(node.getBalanceFactor())<2){
				node=node.getParent();
			}
			if(node!=null){
				flag=node.getParent();
				int bf=node.getBalanceFactor();
				//判断旋转类型
				if(bf==2){
					if(node.getLeftChild().getBalanceFactor()==-1
							||node.getLeftChild().getBalanceFactor()==0){
						rotation(node,AVLTree.LR);
					}
					else if(node.getLeftChild().getBalanceFactor()==1){
						rotation(node,AVLTree.LL);
					}
				}
				if(bf==-2){
					if(node.getRightChild().getBalanceFactor()==-1){
						rotation(node,AVLTree.RR);
					}
					else if(node.getRightChild().getBalanceFactor()==1
							||node.getRightChild().getBalanceFactor()==0){
						rotation(node,AVLTree.RL);
					}
				}
				node=flag;
			}
			else{
				flag=null;
			}
		}
	}
	@Override
	public JTree printTree() {
		return new JTree(buildJTree(this.root));
	}

	/**
	 * 递归算法，后序遍历，构建JTree节点<br>
	 * 
	 * 采用递归算法，时间效率不高，而且容易栈溢出，经测试，在Ubuntu14.04、4G内存、core i7 2.5GHz、JDK1.8下，
	 * 可达到的最大栈深度为10000左右，也就是说，树的高度在10000以下时不会发生StackOverFlowError，也就是说，
	 * 节点数最大可达在2^10000-1个。<br>
	 * 
	 * 哇咔哒，算出来我都吓呆了，时间效率不考虑的话，平时使用使用递归算法还是可取的，以前一直以为担心递归栈溢出
	 * @return JTree节点类
	 */
	private DefaultMutableTreeNode buildJTree(Node<T> node){
		if(node==null){
			return null;
		}
		DefaultMutableTreeNode left=buildJTree(node.getLeftChild());
		DefaultMutableTreeNode right=buildJTree(node.getRightChild());
		//以节点的id、data构建JTree节点
		DefaultMutableTreeNode treeNode=new DefaultMutableTreeNode(node.getData().toString()
				+"("+node.getId()+")");
		if(left!=null){
			treeNode.add(left);
		}
		if(right!=null){
			treeNode.add(right);
		}
		return treeNode;
	}
	/**
	 * 获取二叉平衡树的节点数
	 * @return 节点数
	 */
	public int getNodeNumber() {
		return nodeNumber;
	}
	/**
	 * 获取根节点
	 * @return 根节点
	 */
	public Node<T> getRoot() {
		return root;
	}
}
