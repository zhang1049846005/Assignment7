import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;


public class TestAVLTree extends JFrame{
	private static final long serialVersionUID = 1L;
	private JTree jTree;
	private AVLTree<String> tree;
	
	public TestAVLTree(){
		this.setTitle("AVLTree");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();
		int width=(int) screen.getWidth();
		int height=(int)screen.getHeight();
		this.setBounds(width*3/8, height/4, width/4, height/2);
		
		tree=new AVLTree<>();
		
		try {
			BufferedReader in=new BufferedReader(new FileReader("tree_data.dat"));
			ArrayList<Node<String>> nodes=new ArrayList<>();
			String data=null;
			while((data=in.readLine())!=null){
				String[] line=data.split("#");
				nodes.add(new Node<String>(Integer.parseInt(line[1]),line[0]));
			}
			in.close();
			nodes.stream().forEach((node)->{
				try {
					tree.insert(node);
				} catch (AVLTreeException e1){
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Error", JOptionPane.CLOSED_OPTION);
					e1.printStackTrace();
				}
			});
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		jTree=tree.printTree();
		//打开所有的节点
		this.openAllNode(jTree);
		
		JPanel option=new JPanel();
		option.setLayout(new GridLayout(1,3));
		
		JScrollPane showTree=new JScrollPane();
		showTree.setViewportView(jTree);
		
		JButton add=new JButton("add");
		add.addActionListener((e)->{
			String id=JOptionPane.showInputDialog(null, "Please enter the id:",
					"Id",JOptionPane.PLAIN_MESSAGE);
			String data=null;
			if(id!=null){
				data=JOptionPane.showInputDialog(null, "Please enter the Data:",
						"Data",JOptionPane.PLAIN_MESSAGE);
			}
			if(id!=null&&!id.matches("\\s*")&&data!=null){
				try {
					tree.insert(new Node<String>(Integer.parseInt(id.replaceAll("\\s*", "")),data));
				} catch (AVLTreeException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Error", JOptionPane.CLOSED_OPTION);
					e1.printStackTrace();
				}
			}
			jTree=tree.printTree();
			this.openAllNode(jTree);
			showTree.setViewportView(jTree);
		});
		option.add(add);
		
		JButton delete=new JButton("delete");
		delete.addActionListener((e)->{
			String id=JOptionPane.showInputDialog(null,
					"Please enter the id of node you are deleting!",
					"Deleting",JOptionPane.PLAIN_MESSAGE);
			if(id!=null&&!id.matches("\\s*")){
				try {
					tree.delete(Integer.parseInt(id.replaceAll("\\s*", "")));
					JOptionPane.showMessageDialog(null, "Deleted!", "Deleted", JOptionPane.CLOSED_OPTION);
				} catch (AVLTreeException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Error", JOptionPane.CLOSED_OPTION);
					e1.printStackTrace();
				}
				jTree=tree.printTree();
				this.openAllNode(jTree);
				showTree.setViewportView(jTree);
			}
		});
		option.add(delete);
		
		JButton search=new JButton("Search");
		search.addActionListener((e)->{
			String id=JOptionPane.showInputDialog(null,
					"Please enter the id of node you are searching!",
					"Search",JOptionPane.PLAIN_MESSAGE);
			if(id!=null&&!id.matches("\\s*")){
				Node<String> node;
				try {
					node = tree.get(Integer.parseInt(id.replaceAll("\\s*", "")));
					JOptionPane.showMessageDialog(null, node.getData(),
							"The data of the node:", JOptionPane.CLOSED_OPTION);
				} catch (AVLTreeException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Error", JOptionPane.CLOSED_OPTION);
					e1.printStackTrace();
				}
			}
		});
		option.add(search);
		
		this.add(option,BorderLayout.NORTH);
		this.add(showTree,BorderLayout.CENTER);
		this.setVisible(true);
	}
	public static void main(String[] args){
		SwingUtilities.invokeLater(()->{
			new TestAVLTree();
		});
	}
	//使所有的节点打开
	private void openAllNode(JTree tree){
		for(int i=0;i<tree.getRowCount();i++){
			tree.expandRow(i);
		}
	}
}
