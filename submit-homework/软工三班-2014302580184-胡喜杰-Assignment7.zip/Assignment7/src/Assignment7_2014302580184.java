import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * 作业：根据结构需求实现一个平衡二叉树(AVL树).Node类的samplesample已经给出.请将所有的模拟数据全部存进AVL树中.
 * 要求：
 * 1. 主类 （AVLTree）需要实现接口IAVLTree。
 * 2. 所有的 AVLTree功能需要根据AVL树定义的标准进行实现,尤其是树旋转 。
 * 3. 请将你所有功能的演示结果及其截图写进实验报告中 （电子版 ），并将精简后的文字结果写进纸质实验报告中 。
 *
 * 学号：2014302580184
 * 姓名：胡喜杰
 * 时间：2015.12.27
 */
public class Assignment7_2014302580184 {
    public static void main(String[] args) {
        Node targetNode = new Node();
        AVLTree tree = new AVLTree();
        try{
            initTree(tree);
        }catch (Exception e) {
            e.printStackTrace();
        }

/*        //get方法示例
        targetNode = tree.get(10);
        System.out.println(targetNode.getId());
        System.out.println(targetNode.getData());*/

/*        //insert方法示例
        targetNode.setId(18);
        targetNode.setData("home");
        tree.insert(targetNode);*/

/*        //delete方法示例
        tree.delete(17);*/
        showTree(tree);
    }

    //初始化树
    public static void initTree(AVLTree tree) throws Exception {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("E:\\Office\\面向程序设计(JAVA)\\Assignment7\\src\\tree_data.dat")));
        for(String line = bufferedReader.readLine();line!=null;line = bufferedReader.readLine()) {
            String[] messages = line.split("#");
            Node node = new Node();
            node.setData(messages[0]);
            node.setId(Integer.valueOf(messages[1]));
            tree.insert(node);
        }
        bufferedReader.close();
    }

    //展示树
    public static void showTree(AVLTree tree) {
        JFrame jFrame = new JFrame("AVLTree");
        jFrame.setBounds(200,100,500,500);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JTree jTree = tree.printTree();
        jFrame.add(jTree);
    }
}
