import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;



public class TreeTest {
	
	public static JScrollPane scrollPane;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AVLTree tree = new AVLTree();
		tree.insert(1, new Node(1,"ant"));
		tree.insert(2, new Node(2,"apple"));
		tree.insert(3, new Node(3,"art"));
		tree.insert(4, new Node(4,"baby"));
		tree.insert(5, new Node(5,"banana"));
		tree.insert(6, new Node(6,"car"));
		tree.insert(7, new Node(7,"door"));
		tree.insert(8, new Node(8,"dress"));
		tree.insert(9, new Node(9,"frog"));
		tree.insert(10, new Node(10,"love"));
		tree.insert(11, new Node(11,"mint"));
		tree.insert(12, new Node(12,"rice"));
		tree.insert(13, new Node(13,"show"));
		tree.insert(14, new Node(14,"table"));
		tree.insert(15, new Node(15,"tree"));
		tree.insert(16, new Node(16,"trouble"));
		tree.insert(17, new Node(17,"window"));
		
		
		JTree t = tree.printTree();
		JFrame f = new JFrame("JTree");
        f.setSize(300,450);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        //ΪJTree���ӹ�����
        scrollPane = new JScrollPane();
        scrollPane.getViewport().add(t, null);
        f.setLayout(new BorderLayout());
        f.add(scrollPane,BorderLayout.CENTER); 
        JPanel p =new JPanel(new GridLayout(1,3));
        p.setMaximumSize(new Dimension(300,30));
        p.setMinimumSize(new Dimension(300,30));
        p.setPreferredSize(new Dimension(300,30));
        f.add(p,BorderLayout.SOUTH);
        
        //���Ӱ�ť
        JButton btn1 = new JButton("���ӽڵ�");
        JButton btn2 = new JButton("���ҽڵ�");
        JButton btn3 = new JButton("ɾ���ڵ�");
        p.add(btn1);
        p.add(btn2);
        p.add(btn3);
        
        //������ӽڵ�
        btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Gui gui = new Gui("����",tree);
				gui.setVisible(true);
			}
		});
        
        //������ҽڵ�
        btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Gui gui = new Gui("����",tree);
				gui.setVisible(true);
			}
		});
        
        //���ɾ���ڵ�
        btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Gui gui = new Gui("ɾ��",tree);
				gui.setVisible(true);
			}
		});
	}
	
}
