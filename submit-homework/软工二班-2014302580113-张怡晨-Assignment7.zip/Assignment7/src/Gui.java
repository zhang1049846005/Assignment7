import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Gui extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField1;
	private JTextField textField2;


	/**
	 * Create the frame.
	 */
	public Gui(String str,AVLTree tree) {

		setBounds(100, 100, 300, 250);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("�������"+str+"�Ľڵ���Ϣ");
		label.setBounds(60, 39, 198, 21);
		contentPane.add(label);
		
		//������ӽڵ㰴ťʱ��frame��ʾ
		if(str.equals("����")){
			JLabel lblId1 = new JLabel("id");
			lblId1.setBounds(40, 70, 42, 21);
			contentPane.add(lblId1);
			
			JLabel lblId2 = new JLabel("data");
			lblId2.setBounds(40, 110, 42, 21);
			contentPane.add(lblId2);
			
			textField1 = new JTextField();
			textField1.setBounds(85, 70, 153, 27);
			contentPane.add(textField1);
			textField1.setColumns(10);
			
			textField2 = new JTextField();
			textField2.setBounds(85, 110, 153, 27);
			contentPane.add(textField2);
			textField2.setColumns(10);
		}
		//������ҽڵ��ɾ���ڵ㰴ťʱ��frame��ʾ
		else{
			JLabel lblId = new JLabel("id");
			lblId.setBounds(40, 90, 42, 21);
			contentPane.add(lblId);
			
			textField = new JTextField();
			textField.setBounds(85, 87, 153, 27);
			contentPane.add(textField);
			textField.setColumns(10);
		}
		
		JButton button = new JButton("ȷ��");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//�����ӽڵ�ҳ���µ��ȷ��
				if(str.equals("����"))
				{
					int id = Integer.parseInt(textField1.getText());
					if(tree.get(id)!=null)
						JOptionPane.showMessageDialog(contentPane,"�ýڵ��Ѵ���","����" ,JOptionPane.PLAIN_MESSAGE);
					else
					{
						tree.insert(Integer.parseInt(textField1.getText()), new Node(Integer.parseInt(textField1.getText()),textField2.getText()));
						TreeTest.scrollPane.getViewport().add(tree.printTree(), null);
					}
				}
				//�ڲ��ҽڵ�ҳ���µ��ȷ��
				else if(str.equals("����"))
				{
					//�½�frame
					Node result = tree.get(Integer.parseInt(textField.getText()));
					JFrame frame = new JFrame("result");
					frame.setSize(300,250);
			        frame.setVisible(true);
			        //��textarea����ʾ�����ҽڵ����Ϣ
			        JTextArea area = new JTextArea();
			        area.setEditable(false);
			        area.setFont(new Font("Serif",Font.BOLD,15));
			        JScrollPane jScrollPane = new JScrollPane();
			        jScrollPane.getViewport().add(area, null);
			        frame.setLayout(new BorderLayout());
			        frame.add(jScrollPane,BorderLayout.CENTER); 
			        area.append("�����ҽڵ㣺"+result.getData().toString()+"#"+result.getId()+"\n");
			        if(result.getParent()!=null)
			        	area.append("���ڵ㣺"+result.getParent().getData().toString()+" # "+result.getParent().getId()+"\n");
			        else
			        	area.append("�޸��ڵ�\n");
			        if(result.getChild(0)!=null)
			        	area.append("���ӣ�"+result.getChild(0).getData().toString()+" # "+result.getChild(0).getId()+"\n");
			        else
			        	area.append("������\n");
			        if(result.getChild(1)!=null)
			        	area.append("�Һ��ӣ�"+result.getChild(1).getData().toString()+" # "+result.getChild(1).getId());
			        else
			        	area.append("���Һ���\n");
				}
				//��ɾ���ڵ�ҳ���µ��ȷ��
				else if(str.equals("ɾ��"))
				{
					tree.delete(Integer.parseInt(textField.getText()));
					TreeTest.scrollPane.getViewport().add(tree.printTree(), null);
				}
				setVisible(false);
			}
		});
		button.setBounds(88, 150, 90, 29);
		contentPane.add(button);
	}
}
