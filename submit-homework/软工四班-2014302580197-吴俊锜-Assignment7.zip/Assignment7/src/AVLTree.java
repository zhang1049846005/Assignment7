import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{

	private Node root;
	private boolean unBalanced;
	private Node rootParent;
	
	@Override
	/**
	 * ͨ��id��ȡ��Ӧ�Ľڵ�
	 */
	public Node get(int id) {
		// TODO Auto-generated method stub
		root=rootParent.getChildren()[0];
		Node node=getNodeByID(root,id);
		if(node==null)
			throw new RuntimeException("�ڵ�"+id+"������");
		return getNodeByID(root, id);
	}

	@Override
	/**
	 * �����½ڵ�,���ýڵ��Ѿ��������׳�RuntimeException
	 */
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		unBalanced=false;
		if(root==null){
			root=newNode;
			rootParent=new Node();
			root.setParent(rootParent);
			root.getParent().getChildren()[0]=root;
			return;
		}
		root=rootParent.getChildren()[0];
		Node temp=getNodeByID(root,getInsertIndex(root, newNode));
		if(temp.getId()<newNode.getId()){
			temp.getChildren()[1]=newNode;
			temp.getChildren()[1].setParent(temp);
			while(temp.getParent()!=rootParent){
				if(insertAdjust(temp)){
					break;
				}
				temp=temp.getParent();
			}
		}
		else{
			temp.getChildren()[0]=newNode;
			temp.getChildren()[0].setParent(temp);
			while(temp.getParent()!=rootParent){
				if(insertAdjust(temp)){
					break;
				}
				temp=temp.getParent();
			}
		}
	}

	@Override
	/**
	 * ����idɾ����Ӧ�ڵ�,��Ҫɾ���Ľڵ㲻�������׳�RuntimeException
	 */
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node temp=get(id);
		if(temp==null){
			throw new RuntimeException("�ڵ�"+id+"������");
		}
		Node tempParent=temp.getParent();
		Node []tempChildren=temp.getChildren();
		Node []tempParentChildren=tempParent.getChildren();
		//ɾ��Ҷ�ӵ����
		if(tempChildren[0]==null&&tempChildren[1]==null){
			if(temp==tempParent.getChildren()[0]){
				tempParent.getChildren()[0]=null;
				tempParent.setBalanceFactor(tempParent.getBalanceFactor()-1);
				if(tempParentChildren[1]==null){
					return;
				}
				if(tempParentChildren[1].getBalanceFactor()==0){
					return;
				}
				if(tempParentChildren[1].getBalanceFactor()==1){
					Rotation(tempParentChildren[1]);
					return;
				}
			}else{
				tempParent.getChildren()[1]=null;
				tempParent.setBalanceFactor(tempParent.getBalanceFactor()+1);
				if(tempParentChildren[0]==null){
					return;
				}
				if(tempParentChildren[0].getBalanceFactor()==0){
					return;
				}
				if(tempParentChildren[0].getBalanceFactor()==1){
					Rotation(tempParentChildren[0]);
					return;
				}
			}
		}
		//������Ϊ����������Ϊ��
		if(tempChildren[0]==null){
			if(temp==tempParent.getChildren()[0]){
				tempParent.getChildren()[0]=tempChildren[1];
				tempChildren[1].setParent(tempParent);
				tempParent.setBalanceFactor(tempParent.getBalanceFactor()-1);
				if(tempParentChildren[1].getBalanceFactor()==0){
					return;
				}
				if(tempParentChildren[1].getBalanceFactor()==1){
					Rotation(tempParentChildren[1]);
					return;
				}else{
					Rotation(tempParentChildren[1]);
					return;
				}
			}else{
				tempParent.getChildren()[1]=tempChildren[1];
				tempChildren[1].setParent(tempParent);
				tempParent.setBalanceFactor(tempParent.getBalanceFactor()+1);
				if(tempParentChildren[0].getBalanceFactor()==0){
					return;
				}
				if(tempParentChildren[0].getBalanceFactor()==1){
					Rotation(tempParentChildren[0]);
					return;
				}else{
					Rotation(tempParentChildren[0]);
					return;
				}
			}
		}
		//������Ϊ����������Ϊ��
		if(tempChildren[1]==null){
			if(temp==tempParent.getChildren()[0]){
				tempParent.getChildren()[0]=tempChildren[0];
				tempChildren[0].setParent(tempParent);
				tempParent.setBalanceFactor(tempParent.getBalanceFactor()-1);
				if(tempParentChildren[1].getBalanceFactor()==0){
					return;
				}
				if(tempParentChildren[1].getBalanceFactor()==1){
					Rotation(tempParentChildren[1]);
					return;
				}else{
					Rotation(tempParentChildren[1]);
					return;
				}
			}else{
				tempParent.getChildren()[1]=tempChildren[0];
				tempChildren[0].setParent(tempParent);
				tempParent.setBalanceFactor(tempParent.getBalanceFactor()+1);
				if(tempParentChildren[0].getBalanceFactor()==0){
					return;
				}
				if(tempParentChildren[0].getBalanceFactor()==1){
					Rotation(tempParentChildren[0]);
					return;
				}else{
					Rotation(tempParentChildren[0]);
					return;
				}
			}
		}
		//������������Ϊ��
		if(tempChildren[0]!=null&&tempChildren[1]!=null){
			Node replaceNode=tempChildren[1];
			Node []replaceNodeChildren=replaceNode.getChildren();
			while(replaceNodeChildren[0]!=null){
				replaceNode=replaceNodeChildren[0];
				replaceNodeChildren=replaceNode.getChildren();
			}
			delete(replaceNode.getId());
			if(replaceNode.getParent()==temp){
				temp.setBalanceFactor(temp.getBalanceFactor()+1);
			}
			if(replaceNode.getParent().getBalanceFactor()>0){
				temp.setBalanceFactor(temp.getBalanceFactor()+1);
			}
			temp.setId(replaceNode.getId());
			temp.setData(replaceNode.getData());
		}
	}

	@Override
	/**
	 * ���ö���ƽ������JTree�������ʽ����
	 */
	public JTree printTree() {
		// TODO Auto-generated method stub
		Node rootNode=rootParent.getChildren()[0];
		DefaultMutableTreeNode root=new DefaultMutableTreeNode(rootNode.getData());
		JTree tree=new JTree(root);
		Node []rootChildren=rootNode.getChildren();
		Node lRoot=rootChildren[0];
		Node rRoot=rootChildren[1];
		if(lRoot!=null)
			insertNodeToTree(lRoot,root);
		if(rRoot!=null)
			insertNodeToTree(rRoot,root);
		return tree;
	}
	
	/**
	 * ����������ת
	 * @param r
	 */
	private void Rotation(Node r){
		Node s=r.getParent();
		Node []sChildren=s.getChildren();
		Node []rChildren=r.getChildren();
		Node u;
		if(s.getBalanceFactor()<=-2&&r.getBalanceFactor()>0){	//RL��ת
			u=rChildren[0];
			Node [] uChildren=u.getChildren();
			sChildren[1]=uChildren[0];
			rChildren[0]=uChildren[1];
			uChildren[0]=s;
			uChildren[1]=r;
			u.setParent(s.getParent());
			if(s==s.getParent().getChildren()[0])
				s.getParent().getChildren()[0]=u;
			else
				s.getParent().getChildren()[1]=u;
			r.setParent(u);
			s.setParent(u);
			s.setBalanceFactor(0);
			r.setBalanceFactor(0);
			while(u.getParent()!=rootParent){
				u=u.getParent();
				u.setBalanceFactor(u.getBalanceFactor()+1);
			}
		}else if(s.getBalanceFactor()>=2&&r.getBalanceFactor()>0){	//LL��ת
			sChildren[0]=rChildren[1];
			rChildren[1]=s;
			r.setParent(s.getParent());
			if(s==s.getParent().getChildren()[0])
				s.getParent().getChildren()[0]=r;
			else
				s.getParent().getChildren()[1]=r;
			s.setParent(r);
			while(r.getParent()!=rootParent){
				r=r.getParent();
				r.setBalanceFactor(r.getBalanceFactor()-1);
			}
		}else if(s.getBalanceFactor()<=-2&&r.getBalanceFactor()<0){	//RR��ת
			sChildren[1]=rChildren[0];
			rChildren[0]=s;
			r.setParent(s.getParent());
			if(s==s.getParent().getChildren()[0])
				s.getParent().getChildren()[0]=r;
			else
				s.getParent().getChildren()[1]=r;
			s.setParent(r);
			s.setBalanceFactor(0);
			r.setBalanceFactor(0);
			while(r.getParent()!=rootParent){
				r=r.getParent();
				r.setBalanceFactor(r.getBalanceFactor()+1);
			}
		}else{	//LR��ת
			u=rChildren[1];
			Node []uChildren=u.getChildren();
			sChildren[0]=uChildren[1];
			rChildren[1]=uChildren[0];
			uChildren[0]=r;
			uChildren[1]=s;
			u.setParent(s.getParent());
			if(s==s.getParent().getChildren()[0])
				s.getParent().getChildren()[0]=u;
			else
				s.getParent().getChildren()[1]=u;
			s.setParent(u);
			r.setParent(u);
			s.setBalanceFactor(0);
			r.setBalanceFactor(0);
			while(u.getParent()!=rootParent){
				u=u.getParent();
				u.setBalanceFactor(u.getBalanceFactor()-1);
			}
		}
		unBalanced=false;
	}
	
	/**
	 * ��ȡ��Ҫ�����½ڵ�ĸ��ڵ��λ��
	 * @param p �ӽڵ�p��ʼѰ�Ҳ���λ��
	 * @param newNode Ҫ������½ڵ�
	 * @return
	 */
	private int getInsertIndex(Node p,Node newNode){
		if(p.getId()==newNode.getId())
			throw new RuntimeException("�ڵ�"+newNode.getId()+"�Ѿ�����");
		Node [] pChildren=p.getChildren();
		if(pChildren[0]==null&&p.getId()>newNode.getId()){
			pChildren[0]=newNode;
			p.setBalanceFactor(p.getBalanceFactor()+1);
			unBalanced=true;
			return p.getId();
		}else if(pChildren[1]==null&&p.getId()<newNode.getId()){
			pChildren[1]=newNode;
			p.setBalanceFactor(p.getBalanceFactor()-1);
			unBalanced=true;
			return p.getId();
		}
		else if(newNode.getId()<p.getId()){
			p.setBalanceFactor(p.getBalanceFactor()+1);
			return getInsertIndex(pChildren[0],newNode);
		}else{
			p.setBalanceFactor(p.getBalanceFactor()-1);
			return getInsertIndex(pChildren[1],newNode);
		}
	}
	
	/**
	 * ����֮����еĵ�������
	 * @param node ����ڵ�ĸ��ڵ�
	 * @return
	 */
	private boolean insertAdjust(Node node){
		if(unBalanced&&(node.getParent().getBalanceFactor()<=-2||node.getParent().getBalanceFactor()>=2)){
			Rotation(node);
			return true;
		}
		return false;
	}
	
	/**
	 * ͨ��ID����ýڵ�
	 * @param node �ӽڵ�node��ʼ����
	 * @param id	Ҫ�����ڵ��ID
	 * @return
	 */
	private Node getNodeByID(Node node,int id){
		if(node==null)
			return null;
		if(node.getId()==id)
			return node;
		Node [] children=node.getChildren();
		if(node.getId()>id)
			return getNodeByID(children[0], id);
		else
			return getNodeByID(children[1], id);
	}
	
	/**
	 * �Ѹýڵ���뵽JTree��
	 * @param node	Ҫ�����Node�ڵ�
	 * @param parentTreeNode	Ҫ����ڵ�ĸ��ڵ�TreeNode
	 */
	private void insertNodeToTree(Node node,DefaultMutableTreeNode parentTreeNode){
		DefaultMutableTreeNode treeNode=new DefaultMutableTreeNode(node.getData());
		parentTreeNode.add(treeNode);
		Node []nodeChildren=node.getChildren();
		if(nodeChildren[0]!=null){
			insertNodeToTree(nodeChildren[0],treeNode);
		}
		if(nodeChildren[1]!=null){
			insertNodeToTree(nodeChildren[1],treeNode);
		}
		return;
	}
	
}
